function J_AKGDH=AKGDH(aKGm,COAm,NADm,SCAm,NADHm,CO2,pH_m,p)
% Reaction 4: AKG dehydrogenase (AKGDH)- Enzyme
% AKGm + CoAm + NADm ⇌ SCoAm + NADHm + CO2 + Hm				

%%% Thermodynamics and pH               
dGr0= -37.08; % kJ/mol Gibbs free energy of the reaction at pH=7
Keq0=exp(-dGr0/(p.R_con*p.Tem));
Keq=Keq0*10^(pH_m-7); % pH correction 

% Assigne Km parameters (Zhang 2018)    
KA=85.87e-6;    % M alpha-ketoglutrate
KB=1.634e-6;    % M coenzyme A
KC=46.6e-6;     % M NAD
KD=1.63e-6;     % M Succinyl-coenzyme A 
KE=7.14e-6;     % M NADH
KF=1e-5;   % CO2, is constant 

%%% Assign conct 
A=aKGm;    
B=COAm;    
C=NADm;    
D=SCAm;    
E=NADHm;
F=CO2;

%%% Flux 
deno=(1+C/KC+E/KE)*(1+B/KB+D/KD)*(1+A/KA);
J_AKGDH =1/KA/KB/KC*(A*B*C-D*E*F/Keq)/deno;