function J_PDH=PDH(PYRm,COAm,NADm,ACOAm,CO2,NADHm,pH_m,p)
% Reaction 1: Pyruvate dehydrogenase (PDH)- Enzyme
% PYRm + CoAm + NADm ⇌ ACoAm + CO2 + NADHm + Hm+
	
%%% Thermodynamics and pH 
dGr0= -39.64;  % kJ/mol Gibbs free energy of the reaction at pH=7 [Li etal 2011] 
Keq0=exp(-dGr0/(p.R_con*p.Tem));
Keq=Keq0*10^(pH_m-7); % pH correction 

%%% Assign Km parameters (Zhang 2018)
KA=5.08e-3; % M Pyruavte 
KB=1.49e-5; % M Coenzyme A
KC=3.5e-5; % M NAD
KD=1.49e-5; % M Acetyl-coenzyme A 
KE=3.5e-5; % M NADH
KF=1e-5; % M CO2 


%%% assign conct 
A=PYRm;
B=COAm;
C=NADm;
D=ACOAm;
E=NADHm;
F=CO2; % CO2 is a constant (No ODE for CO2) % The effect of CO2 is reflected in estmated Vmax 

%%% flux 
deno=(1+A/KA)*(1+B/KB+D/KD)*(1+C/KC+E/KE);  
J_PDH = 1/KA/KB/KC*(A*B*C-D*E*F/Keq)/deno;