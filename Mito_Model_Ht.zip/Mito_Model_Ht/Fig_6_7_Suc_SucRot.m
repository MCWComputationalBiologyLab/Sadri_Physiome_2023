%% Fig 6 Suc vs SUC+ROT metabolites and fluxes
%% Clear worksapce
close all; clc;
clear all; 
warning off; format long; %format short e;
tic % measure elapsed time 
%% run the model and creat plots
run Driver_AllFig; 
p.ISub=4; % initial substrate 
p.NSub=5; % number of substrates  and last substrate
%% plot settings
text_size= 70; 
linewidth= 10; 
Position1= [.05,.05, 14, 12];
%% remove outliers
Es=3; St=10; Ed=length(Tv)-St;
for i=p.ISub:1:p.NSub
for j=1:1:p.NPar
mx(j,1)=max(Jv(st:Ed,j,i)) % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first')  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+5,j,i); % substitiute the max with the previous value
mn(j,1)=min(Jv(st:Ed,j,i)) % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mn(j,1),1,'first')  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+5,j,i); % substitiute the max with the previous value
end
mx(j,1)=max(Jv(st:Ed,j,i)) % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first')  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+2,j,i); % substitiute the max with the previous value
mx(j,1)=max(Jv(st:Ed,j,i)) % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first')  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+2,j,i); % substitiute the max with the previous value
mx(j,1)=max(Jv(st:Ed,j,i)) % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first')  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+2,j,i); % substitiute the max with the previous value
mx(j,1)=max(Jv(st:Ed,j,i)) % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first')  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+2,j,i); % substitiute the max with the previous value
end

%% plot fluxes
cl =['r','g','b','c','m'];
p.CU_F=1; % to change the unit if required
for i=p.ISub:1:p.NSub
%% DCC1;    SUC-Pi
set(figure(61),'Units','inches','Position',Position1,'PaperPosition',Position1);
plot(Tv(St:Ed),p.CU_F*Jv(St:Ed,p.iDCC1,i),cl(i),'linewidth',linewidth);  hold on
xlabel('Time (min)');     ylabel({'J_D_C_C_S'}); %ylabel({'J_S_U_C_P_i','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
ax=gca;     ax.YLim=[-inf inf];     box off;   
xlim([0 20]);   xticks([0:5:20]);
ylim([0 500]);   yticks([0:100:500]);

%% DCC2:     MAL-Pi
set(figure(62),'Units','inches','Position',Position1,'PaperPosition',Position1);
plot(Tv(St:Ed),p.CU_F*Jv(St:Ed,p.iDCC2,i),cl(i),'linewidth',linewidth);  hold on
xlabel('Time (min)');     ylabel({'J_D_C_C_M'}); %ylabel({'J_M_A_L_P_i','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
ax=gca;     ax.YLim=[-inf inf];     box off;   
xlim([0 20]);   xticks([0:5:20]);
ylim([-500 0]);   yticks([-500:100:0]);

%% SDH
set(figure(63),'Units','inches','Position',Position1,'PaperPosition',Position1);
plot(Tv(St:Ed),p.CU_F*Jv(St:Ed,p.iCII,i),cl(i),'linewidth',linewidth); hold on
xlabel('Time (min)');     ylabel({'J_S_D_H'}); %ylabel({'J_S_D_H','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
ax=gca;     ax.YLim=[-inf inf];     box off;   

%% PIC
set(figure(64),'Units','inches','Position',Position1,'PaperPosition',Position1);
plot(Tv(St:Ed),p.CU_F*Jv(St:Ed,p.iPIC,i),cl(i),'linewidth',linewidth);   hold on
xlabel('Time (min)');     ylabel({'J_P_I_C'}); %ylabel({'J_P_I_C','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
ax=gca;     ax.YLim=[-inf inf];     box off;   
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot metabolite profiles
p.CU_M=1e6; % conversion unit for metabolite
for i=p.ISub:1:p.NSub
%% SUCm
    set(figure(65),'Units','inches','Position',Position1,'PaperPosition',Position1);
    plot(Tv(St:Ed),p.CU_M*Xv(St:Ed,p.iSUCm,i),cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     
    ylabel({'SUCm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold'); box off; 
    xlim([0 20]);   xticks([0:5:20]);
    ylim([0 3]*1e4);    yticks([0:1:3]*1e4); 
    ax = gca;   ax.YAxis.Exponent = 4;
    lgd1=legend({'SUC','SUC+ROT'},'Location','northwest'); legend boxoff;
    lgd1.NumColumns = 1;

%% MALm
    set(figure(66),'Units','inches','Position',Position1,'PaperPosition',Position1);
    plot(Tv(St:Ed),p.CU_M*Xv(St:Ed,p.iMALm,i),cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     
    ylabel({'MALm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold'); box off;  
    xlim([0 20]);   xticks([0:5:20]);
    ylim([0 4]*1e5);    yticks([0:1:4]*1e5); 
    ax = gca;   ax.YAxis.Exponent = 6;

%% OXAm
    set(figure(67),'Units','inches','Position',Position1,'PaperPosition',Position1);
    plot(Tv(St:Ed),p.CU_M*Xv(St:Ed,p.iOXAm,i),cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');   
    ylabel({'OXA (\muM)'})
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold'); box off;  
    xlim([0 20]);   xticks([0:5:20]); 
    ylim([0 1.2]*1e4);    yticks([0:.3:1.2]*1e4); 
    ax = gca;   ax.YAxis.Exponent = 4;

%% Pim
    set(figure(68),'Units','inches','Position',Position1,'PaperPosition',Position1);
    plot(Tv(St:Ed),p.CU_M*Xv(St:Ed,p.iPim,i),cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     
    ylabel({'Pim (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold'); box off;
    xlim([0 20]);   xticks([0:5:20]);
    ylim([1 1.6]*1e4);    yticks([1:.2:1.6]*1e4); 
    ax = gca;   ax.YAxis.Exponent = 4;

%% JO2
    set(figure(69),'Units','inches','Position',Position1,'PaperPosition',Position1);
    plot(Tv(St:Ed),p.CU_F*Jv(St:Ed,p.iPIC,i),cl(i),'linewidth',linewidth);   hold on
    xlabel('Time (min)');    
    ylabel({'J_O_2','(nmol/min/mg)'}); % ylabel({'J_O_2'}); 
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
    ax=gca;    % ax.YLim=[-inf inf];     
    box off;  
    xlim([0 20]);   xticks([0:5:20]); 
    ylim([0 .9]*1e3);    yticks([0:.3:.9]*1e3); 
    ax = gca;   ax.YAxis.Exponent = 2;
end


