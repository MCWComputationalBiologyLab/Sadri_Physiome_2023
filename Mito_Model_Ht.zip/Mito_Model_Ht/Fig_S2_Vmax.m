%% Clear worksapce
close all; 
clear all; 
clc;
warning off; 
format long; 
tic % measure elapsed time 
%% plots settings
Position1E= [.5,.5, 18, 4.5];
text_size= 24; 
linewidth= 3; 
%%% static plots
linewidthBar= 3;
grayColor = [.7 .7 .7];

%% read parameters
load Model_Params_Ht; pht.pest=10.^Params_temp; pht.pest(11,1)=2*pht.pest(11,1);
CUF=1e9; % conversion unit factor to nmol/min/mg
set(figure(91),'Units','inches','Position',Position1E,'PaperPosition',Position1E); % figure setting 
bar(CUF*pht.pest(:,1),'FaceColor', [0.35 0.35 0.35],'EdgeColor','flat','LineWidth',linewidthBar)
ylim([0 10e4]); yticks(0:2e4:10e4)
ylabel({'V_m_a_x',' (nmol/min/mg)'})
set(gca,'xtick',1:24,'xticklabel',{'PDH','CITS','IDH','AKGDH','SCAS','NDK','FH','MDH','GOT','CI','CII',...
    'CIII','CIV','CV','PYRH','GLUH','DCCS','DCCM','TCC','OME','GAE','ANT','PIC','HLeak'});  xtickangle(45) 
set(gcf,'color','w');   set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold'); box off;

