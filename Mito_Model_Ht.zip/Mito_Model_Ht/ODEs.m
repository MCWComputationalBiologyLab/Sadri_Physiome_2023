function dxdt = ODEs(~,x,p)
%   The purpose of this function is to establish the rate equations for
%   chemical reactions of molecular compounds and transport of these
%   compounds between compartments in the metabolism model.
ETfluxes=Fluxes(x,p);
%% TCA fluxes
J_PDH=ETfluxes(1);
J_CITS=ETfluxes(2);
J_IDH=ETfluxes(3);
J_AKGD=ETfluxes(4);
J_SCAS=ETfluxes(5);
J_NDK=ETfluxes(6);
J_FH=ETfluxes(7);
J_MDH=ETfluxes(8);
J_GOT=ETfluxes(9);
J_CI=ETfluxes(10);
J_CII=ETfluxes(11);
J_CIII=ETfluxes(12);
J_CIV=ETfluxes(13);
J_CV=ETfluxes(14);
%% Transporter fluxes
T_PYRH=ETfluxes(15);
T_GLUH=ETfluxes(16);
T_DCCS=ETfluxes(17);
T_DCCM=ETfluxes(18);
T_TCC=ETfluxes(19);
T_OME=ETfluxes(20);
T_GAE=ETfluxes(21);
T_ANT=ETfluxes(22);
T_PIC=ETfluxes(23);
T_HLEAK=ETfluxes(24);

%% Net Equations / Mass Balance
%%% Buffer region 
% -- Nucleotides --
dxdt(p.iADPe) = (-T_ANT)/p.Ve;
dxdt(p.iATPe) = (+T_ANT)/p.Ve;
% -- Substrates --
dxdt(p.iPie)= 1*(T_DCCS -T_PIC +T_DCCM)/p.Ve;
dxdt(p.iPYRe) = 1*(-T_PYRH)/p.Ve;
dxdt(p.iMALe) = 1*(-T_DCCM -T_OME -T_TCC)/p.Ve; % 5
dxdt(p.iCITe) = (+T_TCC)/p.Ve;
dxdt(p.iaKGe) = (+T_OME)/p.Ve;
dxdt(p.iSUCe) = (-T_DCCS)/p.Ve;
dxdt(p.iGLUe) = (-T_GLUH -T_GAE)/p.Ve;
dxdt(p.iASPe) = (T_GAE)/p.Ve; % 10
% -- Ions --
dxdt(p.iHe)=0; 

%%% Mitochondria Martix region 
% -- Nucleotides -
dxdt(p.iPim)  = (-T_DCCS -T_DCCM -J_SCAS -J_CV +T_PIC)/p.Vm; 
dxdt(p.iADPm) = (T_ANT -J_NDK -J_CV)/p.Vm;
dxdt(p.iATPm) = (J_CV +J_NDK -T_ANT)/p.Vm;
dxdt(p.iGDPm) = (-J_SCAS +J_NDK)/p.Vm;
dxdt(p.iGTPm) = -dxdt(p.iGDPm);  % 15
% -- respiratory substrates --
dxdt(p.iNADm) = (-J_PDH -J_IDH - J_AKGD -J_MDH +J_CI)/p.Vm;
dxdt(p.iNADHm) = -dxdt(p.iNADm);
dxdt(p.iUQm) = (-J_CI -J_CII +J_CIII)/p.Vm;
dxdt(p.iUQH2m) = -dxdt(p.iUQm);
dxdt(p.iCytCoxi) = (-2*J_CIII +2*J_CIV)/p.Vi; % 20 % Inter-membrane region
dxdt(p.iCytCred) = -dxdt(p.iCytCoxi); % Inter-membrane region
% -- TCA substrates --
dxdt(p.iGLUm) = (J_GOT +T_GAE +T_GLUH)/p.Vm;
dxdt(p.iASPm) = (-J_GOT -T_GAE)/p.Vm;
dxdt(p.iPYRm) = (T_PYRH -J_PDH)/p.Vm; % 25
dxdt(p.iOXAm) = (-J_CITS +J_MDH+J_GOT)/p.Vm; 
dxdt(p.iCITm) = (-T_TCC +J_CITS -J_IDH)/p.Vm;
dxdt(p.iaKGm)  = (J_IDH -J_GOT -J_AKGD -T_OME)/p.Vm;
dxdt(p.iSCAm)  = (J_AKGD -J_SCAS)/p.Vm;
dxdt(p.iSUCm)  = (+T_DCCS +J_SCAS -J_CII)/p.Vm; % 30
dxdt(p.iFUMm)  =(-J_FH +J_CII)/p.Vm; 
dxdt(p.iMALm)  = (J_FH -J_MDH  +T_DCCM +T_OME +T_TCC)/p.Vm; 
dxdt(p.iCOAm) = (-J_PDH +J_CITS +J_SCAS -J_AKGD)/p.Vm;
dxdt(p.iACOAm)= (J_PDH-J_CITS)/p.Vm;
% -- oxygen consumption --
dxdt(p.iO2m) = p.close_system*0.5*(-J_CIV)/(p.Vm +p.Ve +p.Vi); % 35
% -- memebrane potential --
Cimm=6.75*1e-6*(p.Vm+p.Vi);   % Mito volume (is 1.3e-6 L in Jason's paper). 
dxdt(p.idPsi) = 1/Cimm*(4*J_CI+ 2*J_CIII+ 4*J_CIV -T_ANT -T_HLEAK -T_GAE -p.nH*J_CV ); % 36 
% -- ions / proton leak --
buffer_m= 2.303*10^(-7.6)/43;  % buffer capacity =0.0043 M in matrix
dxdt(p.iHm) = 0*2*(buffer_m*( +T_PYRH +T_GLUH +T_GAE -T_TCC +T_HLEAK +T_PIC ...
    +J_PDH +2*J_CITS +2*J_IDH +J_AKGD +J_SCAS +J_MDH -(4+1)*J_CI -(4-2)*J_CIII -(2+2)*J_CIV +(3-1)*J_CV))/p.Vm; % 37 

%% Output Matrix
dxdt=dxdt';
end

