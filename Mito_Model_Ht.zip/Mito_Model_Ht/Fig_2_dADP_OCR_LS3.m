%% Figure 2 
%% dADP OCR model simulations 
%% Clear worksapce
close all; clc;
clear all; 
warning off; format long; %format short e;
tic % measure elapsed time 
%% run the model
run Driver_AllFig;
% data rows indicate: [PM GM AM Suc SucRot]
JO2_Pkd=[data.JO2_Pk(:,1) data.JO2_Pk(:,2) data.JO2_Pk(:,3) data.JO2_Pk(:,4) data.JO2_Pk(:,5)]; % nM
JO2_Pkd_Err=[data.JO2_Pk_Err(:,1) data.JO2_Pk_Err(:,2) data.JO2_Pk_Err(:,3) data.JO2_Pk_Err(:,4) data.JO2_Pk_Err(:,5)]; % nM
%% plot settings 
Position1= 2*[.5,.5, 5.5, 4.5];
text_size= 40; 
linewidth= 6; 
MarkerSizeErr= 10;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% data rep OCR dynamic with different ADP additions nmol/min/mg mito
ADP_add=[0 25 50 75 100 150 250]*1e-6;
set(figure(20),'Units','inches','Position',Position1,'PaperPosition',Position1);
cl =['r','g','b','c','m'];
for i =p.ISub:1:p.NSub
     plot(data.timev(1:length(data.JO2_nmol_TC(:,i))),data.JO2_nmol_TC(:,i),cl(i),'Linestyle','-.','linewidth',linewidth); hold on
     xlabel('Time (min)');     ylabel({'J_O_2 (nnmol/min/mg)'});
     set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
     box off; hold on
end
hold off
ax=gca; ax.XLim=[0 inf];
ylim([0 800]);  yticks([0:200:800])
xlim([0 20]);  xticks([0:4:20])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% simulation OCR dynamic with different ADP additions 
set(figure(21),'Units','inches','Position',Position1,'PaperPosition',Position1);
cl =['r','g','b','c','m'];
p.sp=3;
for i =p.ISub:1:p.NSub
     OCR(:,i)=movmean(Jv(p.sp:end,p.iCIV,i),5);
end
plot(Tv(p.sp:1210,1),OCR(p.sp:1210,1),cl(1),'linewidth',linewidth); hold on
plot(Tv(p.sp:1210,2),OCR(p.sp:1210,2),cl(2),'linewidth',linewidth); hold on
plot(Tv(p.sp:1210,3),OCR(p.sp:1210,3),cl(3),'linewidth',linewidth); hold on
plot(Tv(p.sp:965,4),OCR(p.sp:965,4),cl(4),'linewidth',linewidth); hold on
plot(Tv(p.sp:965,5),OCR(p.sp:965,5),cl(5),'linewidth',linewidth); hold on
xlabel('Time (min)');     ylabel({'J_O_2 (nnmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
box off;    hold off
ax=gca; ax.XLim=[0 inf];
ylim([0 800]);  yticks([0:200:800])
xlim([0 20]);  xticks([0:4:20])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% simulation OCR peaks fitting to data with error bars 
set(figure(22),'Units','inches','Position',Position1,'PaperPosition',Position1);
p.Es=3;
cl =['r','g','b','c','m'];
Pkvx=[ADP_add]*1e6; UCF=1e9;
for i=p.ISub:1:p.NSub
    plot(Pkvx,UCF*JPk(p.Es:9,p.iCIV,i),cl(i),'linewidth',linewidth); hold on;
    errorbar(Pkvx, JO2_Pkd(:,i), JO2_Pkd_Err(:,i),cl(i),'Marker','o','MarkerSize',MarkerSizeErr,...
        'MarkerFaceColor',cl(i),'LineStyle','none','linewidth',1*linewidth);
end
set(gcf,'color','w');  set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold'); hold on
xlabel('ADP (\muM)');   ylabel('J_O_2 (nmol/min/mg)')
box off;   hold off
ax=gca; ax.YLim=[0 inf];
xlim([0 250]);  xticks([0:50:250])
ylim([0 800]);  yticks([0:200:800])

