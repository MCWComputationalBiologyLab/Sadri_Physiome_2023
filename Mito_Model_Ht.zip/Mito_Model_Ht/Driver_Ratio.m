%% clear workspace % for CIV flux 
clear all
close all
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% declare variables and read parameters
run Read_Condt
load Model_Params_Ht; 
Params_temp=10.^Params_temp;
p.pest(1:p.NPar)=Params_temp; p.pest; % estimated Vmax
%% load data
% data coloumns indicate: [PM GM AM Suc SucRot]
JO2_Pkd=[data.JO2_Pk(:,1) data.JO2_Pk(:,2) data.JO2_Pk(:,3) data.JO2_Pk(:,4) data.JO2_Pk(:,5)]; % nM
JO2_Pk_Err=[data.JO2_Pk_Err(:,1) data.JO2_Pk_Err(:,2) data.JO2_Pk_Err(:,3) data.JO2_Pk_Err(:,4) data.JO2_Pk_Err(:,5)]; % nM

%% substrates and ADP additions 
PYR_index=[1 0 0 0 0];
GLU_index=[0 1 0 0 0];
aKG_index=[0 0 1 0 0];
MAL_index=[1 1 1 0 0];
SUC_index=[0 0 0 1 1];
ADP_add=[0 25 50 75 100 150 250]*1e-6; p.ADPL=length(ADP_add); % uM
options = odeset('NonNegative',[1:p.NOde]); % concentrations of the state variables should be positive
for i=p.ISub:1:p.NSub 
X0=ICs(p); p_tem=p; 
%%% solving ODEs and calculating state variables 
T0=0; jj=1; p.Es=3; % extra states 
cc=1;
for ii=1:1:p.ADPL+p.Es % ii=1: add mito, ii=2: add substrate, ii=3: add Rot i=5, ii=4-9 add 6 doses of ADP
    %%% Substrate addition 
    if ii==p.Es-1
        X0(p_tem.iMALe)=cc*MAL_index(i)*2.5e-3; % mM
        X0(p_tem.iPYRe)=cc*PYR_index(i)*5e-3; % mM
        X0(p_tem.iGLUe)=cc*GLU_index(i)*5e-3; % mM
        X0(p_tem.iaKGe)=cc*aKG_index(i)*5e-3; % mM
        X0(p_tem.iSUCe)=cc*SUC_index(i)*10e-3; % mM
    end
    if i == 5 && ii==p.Es % Rot addition
        p_tem.ini_VTmax(p.iCI)=0*p_tem.ini_VTmax(p.iCI); % inhibit CI
    end 
    %%% ADP addition
    if ii>=p.Es && ii~=p.ADPL+p.Es   
        X0(p_tem.iADPe)=X0(p.iADPe)+ADP_add(jj);
        jj=jj+1;
    end
    %%% Solving ODEs
    tspan=[T0:p.tstep:(T0+p.time(ii,1))];
    [T,X] = ode15s(@ODEs, tspan, X0, options, p_tem);     
    T0=T(end,:);       X0=X(end,:);  % redefining initial values for the next time periode 
    Tc(ii,i)={T};      Xc(ii,i)={X};  
    X(:,p.iADPe);
    %%% Calculating fluxes
    for zz=1:1:length(T) %length(tspan) %length(T)
        J(zz,:,i)=Fluxes(X(zz,:),p_tem);        
    end
    Jc(ii,i)={J(1:zz,:,i)};
    %%% finding peaks of state 3 for ODEs
   if ii<p.Es || ii==p.ADPL+p.Es
        XPk(ii,:,i)=mean(Xc{ii,i}); 
   elseif ii>=p.Es || ii~=p.ADPL+p.Es
        XPk(ii,:,i)=max(Xc{ii,i});
        Xmin(ii,:,i)=min(Xc{ii,i});
   end
   st0=1; st=st0;
    s=13;  % CIV flux- OCR
    %%% finding peaks and length of state 3
   if ii<p.Es || ii==p.ADPL+p.Es
        JPk(ii,i)=mean(J(2:end,s,i));  % returns mean of each column   
        HPk(ii,i)=mean(J(2:end,s,i));
        Ix(ii,i)=0; Ixb(ii,i)=0; Ixf(ii,i)=0; LS3(ii,i)=0;
   elseif ii>=p.Es || ii~=p.ADPL+p.Es
       if  i==4; st=15; else; st=st0; end % for state 2 and Suc start from higher values    
        JPk(ii,i)=max(J(st:end,s,i)); % returns max of each column 
        HPk(ii,i)=.5*max(J(st:end,s,i)); 
        RCI(ii,i)=JPk(ii,i)/JPk(p.Es,i);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%% Find POR
        iADPe_min(ii,i)=min(X(:,p.iADPe));
        iADPe_max(ii,i)=max(X(:,p.iADPe));

        c1=8.7e-7;
        if isempty(find(X(10:end,p.iADPe)<c1,1,'first')); iADPe_Inx1(ii,i)=1; 
        wp=sprintf('cannot find Index ADPe 1 for org=%d ii=%d flx=%d',i,ii,s); disp(wp);
        else iADPe_Inx1(ii,i)=find(X(10:end,p.iADPe)<c1,1,'first');
        end

        c2=8.7e-7;
        if isempty(find(X(10:end,p.iADPe)>c2,1,'last')); iADPe_Inx2(ii,i)=1; 
        wp=sprintf('cannot find Index ADPe 2 for org=%d ii=%d flx=%d',i,ii,s); disp(wp);
        else iADPe_Inx2(ii,i)=find(X(10:end,p.iADPe)>c2,1,'last');
        end

        ADP_add(jj-1);
        counter1=iADPe_Inx2(ii,i);
        C_O2_1(ii,i)=X(1,p.iO2m);
        C_O2_2(ii,i)=X(counter1,p.iO2m);
        dO2(ii,i)=abs(C_O2_2(ii,i)-C_O2_1(ii,i));
        POR(ii,i)=ADP_add(jj-1)/(2*dO2(ii,i));

        if ii==p.ADPL+p.Es-1
            POR(ii,i)=POR(ii-1,i);
        end
        ADPe_start(ii,i)=X(1,p.iADPe);
        ADPe_finish(ii,i)=X(counter1,p.iADPe);
end % close if 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    JPkc(ii,i)={JPk(ii,i)};
    HPkc(ii,i)={HPk(ii,i)};
end % ii time protocol for-loop

% storing cell variables in vectors 
Tv(:,i)=        [Tc{1,i};   Tc{2,i};    Tc{3,i};    Tc{4,i};    Tc{5,i};    Tc{6,i};    Tc{7,i};    Tc{8,i};    Tc{9,i};]; % min
Xv(:,:,i)=1e0*  [Xc{1,i};   Xc{2,i};    Xc{3,i};    Xc{4,i};    Xc{5,i};    Xc{6,i};    Xc{7,i};    Xc{8,i};    Xc{9,i};]; % M
Jv(:,:,i)=1e9*  [Jc{1,i};   Jc{2,i};    Jc{3,i};    Jc{4,i};    Jc{5,i};    Jc{6,i};    Jc{7,i};    Jc{8,i};    Jc{9,i};]; % nmol/min/mg mito
JPkv(:,:,i)=1e9*[JPkc{1,i}; JPkc{2,i};  JPkc{3,i};  JPkc{4,i};  JPkc{5,i};  JPkc{6,i};  JPkc{7,i};  JPkc{8,i};  JPkc{9,i};]; % nmol/min/mg mito
HPkv(:,:,i)=1e0*[HPkc{1,i}; HPkc{2,i};  HPkc{3,i};  HPkc{4,i};  HPkc{5,i};  HPkc{6,i};  HPkc{7,i};  HPkc{8,i};  HPkc{9,i};];

%% plot 
% %%% plot ADPe
% p.sp=3; % start of plot 
% figure(1)
% plot(Tv(p.sp:end,i),Xv(p.sp:end,p.iADPe,i)); hold on
% if i==1; title('PM JO2'); elseif i==2; title('GM JO2');
% elseif i==3; title('AM JO2'); elseif i==4; title('Suc JO2');
% elseif i==5; title('Suc+Rot JO2'); end

% %%% OCR fluxes 
% figure(2); subplot(3,2,i)
% p.sp=3; % start of plot 
% for ii=1:1:p.NPar
% OCR(:,i)=movmean(Jv(p.sp:end,p.iCIV,i),5);
% % plot(Tv(p.sp:end,i),a*Jv(p.sp:end,p.iCIV,i)); hold on % plot without smoothing
% plot(Tv(p.sp:end,i),OCR(:,i)); hold on % plot after smoothing the OCR
% end
% if i==1; title('PM JO2'); elseif i==2; title('GM JO2');
% elseif i==3; title('AM JO2'); elseif i==4; title('Suc JO2');
% elseif i==5; title('Suc+Rot JO2'); end
% 
% figure(3); subplot(3,2,i)
% Pkvx=[ADP_add]*1e6;
% for ii=1:1:p.NPar
% plot(Pkvx,JPkv(p.Es:9,:,i),'-'); hold on
% plot(Pkvx,JO2_Pkd(:,i),'*');
% end
% if i==1; title('PM JO2 Peaks'); elseif i==2; title('GM JO2 Peaks');
% elseif i==3; title('AM JO2 Peaks'); elseif i==4; title('Suc JO2 Peaks');
% elseif i==5; title('Suc+Rot JO2 Peaks'); end
% 
% figure(5); subplot(3,2,i) % NADH dynamic
% plot(Tv(p.sp:end,i),Xv(p.sp:end,p.iNADHm,i)); hold on
% if i==1; title('PM NADH'); elseif i==2; title('GM NADH');
% elseif i==3; title('AM NADH'); elseif i==4; title('Suc NADH');
% elseif i==5; title('Suc+Rot NADH'); end
% 
% figure(6); subplot(3,2,i) % dPsi dynamic
% plot(Tv(p.sp:end,i),Xv(p.sp:end,p.idPsi,i)); hold on
% if i==1; title('PM \Delta\Psi'); elseif i==2; title('GM \Delta\Psi');
% elseif i==3; title('AM \Delta\Psi'); elseif i==4; title('Suc \Delta\Psi');
% elseif i==5; title('Suc+Rot \Delta\Psi'); end
% 
% p.sp=3;
% figure(7); subplot(3,2,i) % ADPe dynamic
% plot(Tv(p.sp:end,i),Xv(p.sp:end,p.iADPe,i)); hold on
% if i==1; title('PM ADPe'); elseif i==2; title('GM ADPe');
% elseif i==3; title('AM ADPe'); elseif i==4; title('Suc ADPe');
% elseif i==5; title('Suc+Rot ADPe'); end

end % i substrate for-loop
