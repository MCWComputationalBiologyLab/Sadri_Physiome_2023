%% Plot correlation coefficient matrix and jacobian matrices
clear all; close all; clc
%% read from sensitivity folder
addpath('.\Sensitivity_CCM')
%% Plot correlation matrix
text_size= 18;  linewidth=6;
load CM;
for i=1:size(CM,1)
    for j=1:size(CM,2)
        if i<j
            CM(i,j)=0;
        end
    end
end
rgmap=ones(22,3);
rgmap(1:11,1)=(0:0.1:1);
rgmap(1:11,2)=(0:0.1:1);
rgmap(12:22,2)=(1:-0.1:0);
rgmap(12:22,3)=(1:-0.1:0);
xvalues={'\bfPDH','\bfCITS','\bfIDH','\bfAKGDH','\bfSCAS','\bfNDK','\bfFH','\bfMDH',...
    '\bfGOT','\bfCI','\bfCII','\bfCIII','\bfCIV','\bfCV','\bfPYRH','\bfGLUH','\bfDCCS',...
    '\bfDCCM','\bfTCC','\bfOME','\bfGAE','\bfANT','\bfPIC','\bfHLeak'};
yvalues={'\bfPDH','\bfCITS','\bfIDH','\bfAKGDH','\bfSCAS','\bfNDK','\bfFH','\bfMDH',...
    '\bfGOT','\bfCI','\bfCII','\bfCIII','\bfCIV','\bfCV','\bfPYRH','\bfGLUH','\bfDCCS',...
    '\bfDCCM','\bfTCC','\bfOME','\bfGAE','\bfANT','\bfPIC','\bfHLeak'};
set(figure(50),'Units','inches','Position',[0.05 0.05 16 13])
h=heatmap(xvalues,yvalues,CM,'Colormap',rgmap,'GridVisible','on','Fontsize',text_size);



