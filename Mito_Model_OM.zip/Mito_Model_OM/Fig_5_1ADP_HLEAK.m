%% proton leak ADP 200uM
%% clear workspace 
clear all
close all
clc
warning off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% read parameters and experimental conditions  
run Read_Condt
p.pest(1:p.NPar)=param; p.pest; % estimated Vmax
%% plot settings
Position1= [.5,.5, 7, 5.5];
text_size= .8*40;
linewidth= 6;
MarkerSize= 6;
MarkerSizeErr= 10;
p.time=[2, 1, 1, 10,5]';% ADPe is obtained at 4th duration 2

%% substrates and ADP additions 
PYR_index=[1 0 0 0 0];
GLU_index=[0 1 0 0 0];
aKG_index=[0 0 1 0 0];
MAL_index=[1 1 1 0 0];
SUC_index=[0 0 0 1 1];
ADP_add=[0 100]*1e-6; p.ADPL=length(ADP_add); % uM
options = odeset('NonNegative',[1:p.NOde]); % concentrations of the state variables should be positive
HLF =[1:1:10]; % HLeak factor
counter1=0; p.Es=3; counter4=20;
counter5=1; % to store T, X and J with different lengths
T0ii=zeros(p.ADPL+p.Es,5);       X0ii=zeros(p.ADPL+p.Es,5);
for j=1:length(HLF)
    HLF(j);
for i=p.ISub:1:p.NSub 
X0=ICs(p); p_tem=p; 
p_tem.pest(p.iHLEAK)=HLF(j)*p.pest(p.iHLEAK); % Proton Leak
%%% solving ODEs and calculating state variables 
T0=0; jj=1; p.Es=3; % extra states 
cc=1;
for ii=1:1:p.ADPL+p.Es % ii=1: add mito, ii=2: add substrate, ii=3: add Rot i=5, ii=4-9 add 6 doses of ADP
    %%% Substrate addition 
    if ii==p.Es-1
        X0(p_tem.iMALe)=cc*MAL_index(i)*2.5e-3; % mM
        X0(p_tem.iPYRe)=cc*PYR_index(i)*5e-3; % mM
        X0(p_tem.iGLUe)=cc*GLU_index(i)*5e-3; % mM
        X0(p_tem.iaKGe)=cc*aKG_index(i)*5e-3; % mM
        X0(p_tem.iSUCe)=cc*SUC_index(i)*10e-3; % mM
    end
    if i==5 && ii==p.Es % Rot addition
        p_tem.ini_VTmax(p.iCI)=0*p_tem.ini_VTmax(p.iCI); % inhibit CI
    end 
    %%% ADP addition
    if ii>=p.Es && ii~=p.ADPL+p.Es   
        X0(p_tem.iADPe)=X0(p.iADPe)+ADP_add(jj);
        jj=jj+1;
    end
    %%% Solving ODEs
    tspan=[T0:p.tstep:(T0+p.time(ii,1))];
    [T,X] = ode15s(@ODEs, tspan, X0, options, p_tem);   
    T0=T(end,:);       X0=X(end,:);  % redefining initial values for the next time period
    TL(ii,i,j)=length(T);
    Tc(ii,i,j)={T};      Xc(ii,i,j)={X};  
    %%% Calculating fluxes
    for zz=1:1:length(T) 
        J(zz,:,i)=Fluxes(X(zz,:),p_tem);        
    end
    Jc(ii,i,j)={J(1:zz,:,i)};
    %%% finding peaks of state 3 for ODEs
   st0=5; st=st0;
   if ii<p.Es || ii==p.ADPL+p.Es
        Xmax(ii,:,i)=mean(Xc{ii,i}); 
   elseif ii>=p.Es || ii~=p.ADPL+p.Es
       if  i==4; st=2; else; st=1; end % for state 2 and Suc start from higher values    
        Xmax(ii,:,i)=max(Xc{ii,i});
        Xmin(ii,:,i)=min(Xc{ii,i});
   end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Find peaks of state 3 for fluxes
    s=13;  % CIV flux- OCR
   if ii<p.Es || ii==p.ADPL+p.Es
        JPk(ii,i)=mean(J(st:end,s,i)); % returns mean of each column   
        HPk(ii,i)=mean(J(st:end,s,i));
   elseif ii>=p.Es || ii~=p.ADPL+p.Es
        JPk(ii,i)=max(J(st:end,s,i)); % returns max of each column 
        HPk(ii,i)=.5*max(J(st:end,s,i)); 
        RCI(ii,i,j)=JPk(ii,i)/JPk(p.Es,i);
        St2_OCR(i,j)=JPk(p.Es,i);
        dPsi_min(ii,i,j)=Xmin(ii,p.idPsi,i);
        dPsi_max(ii,i,j)=Xmax(ii,p.idPsi,i);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Calculate redox ratios and POR, ... 
    c1=8.7e-7;
    if isempty(find(X(10:end,p.iADPe)<c1,1,'first')); iADPe_Inx1(ii,i,j)=1; 
        wp=sprintf('cannot find Index ADPe 1 for org=%d ii=%d flx=%d',i,ii,s); disp(wp);
    else iADPe_Inx1(ii,i,j)=find(X(10:end,p.iADPe)<c1,1,'first');
    end

    c2=2.5e-7;
    if isempty(find(X(10:end,p.iADPe)>c2,1,'last')); iADPe_Inx2(ii,i,j)=1; 
        wp=sprintf('cannot find Index ADPe 2 for org=%d ii=%d flx=%d',i,ii,s); disp(wp);
    else iADPe_Inx2(ii,i,j)=find(X(10:end,p.iADPe)>c2,1,'last'); 
        ADP_add(jj-1); ii_keep=ii;
        counter1=iADPe_Inx2(ii,i,j); % for C_O2
        counter3_PO(ii,i,j)= iADPe_Inx2(ii,i,j); % for dC_O2
        C_O2_1(ii,i,j)=X(1,p.iO2m);
        C_O2_2(ii,i,j)=X(counter1,p.iO2m);
        dO2(ii,i,j)=abs(C_O2_2(ii,i,j)-C_O2_1(ii,i,j));
        POR(ii,i,j)=ADP_add(jj-1)/(2*dO2(ii,i,j));
        ADP_add(jj-1);
        %%% calculate max an min
        iADPe_min(ii,i,j)=min(X(:,p.iADPe));
        iADPe_max(ii,i,j)=max(X(:,p.iADPe));
        Xmax_NADH(ii,i,j)=Xmax(ii,p.iNADHm,i);
        Xmin_NADH(ii,i,j)=Xmin(ii,p.iNADHm,i);
        Xmax_QH2(ii,i,j)=Xmax(ii,p.iUQH2m,i);
        Xmin_QH2(ii,i,j)=Xmin(ii,p.iUQH2m,i);
        Xmax_Cytc(ii,i,j)=Xmax(ii,p.iCytCred,i);
        Xmin_Cytc(ii,i,j)=Xmin(ii,p.iCytCred,i);
        ADPe_start(ii,i,j)=X(1,p.iADPe);
        ADPe_finish(ii,i,j)=X(counter1,p.iADPe);
    end % if find ADP_Inx

    end % if ii
    Pkc(ii,i)={JPk(ii,i)};
    HPkc(ii,i)={HPk(ii,i)};
end % for ii

% storing variables
if j~=1 && sum(TL(:,i,j))~=sum(TL(:,i,j-1))
c5=1;   TL_add_0=abs(sum(TL(:,i,j))-sum(TL(:,i,j-1)));
T_add_0(:,1:5,c5)={zeros(TL_add_0,1)};
X_add_0(:,37,c5)={zeros(TL_add_0,37,1)};
J_add_0(:,24,c5)={zeros(TL_add_0,24,1)};
Tv(:,i,j)=      [Tc{1,i,j};   Tc{2,i,j};    Tc{3,i,j};    Tc{4,i,j};    Tc{5,i,j};  T_add_0{:,i,c5}];
Xv(:,:,i)=1e0*  [Xc{1,i,j};   Xc{2,i,j};    Xc{3,i,j};    Xc{4,i,j};    Xc{5,i,j};  X_add_0{:,:,c5}]; % M
Jv(:,:,i)=1e9*  [Jc{1,i,j};   Jc{2,i,j};    Jc{3,i,j};    Jc{4,i,j};    Jc{5,i,j};  J_add_0{:,:,c5}]; % nmol/min/mg mito
elseif j==1 || sum(TL(:,i,j))==sum(TL(:,i,j-1))
Tv(:,i,j)=      [Tc{1,i,j};   Tc{2,i,j};    Tc{3,i,j};    Tc{4,i,j};    Tc{5,i,j};];
Xv(:,:,i)=1e0*  [Xc{1,i,j};   Xc{2,i,j};    Xc{3,i,j};    Xc{4,i,j};    Xc{5,i,j};]; % M
Jv(:,:,i)=1e9*  [Jc{1,i,j};   Jc{2,i,j};    Jc{3,i,j};    Jc{4,i,j};    Jc{5,i,j};]; % nmol/min/mg mito
end

% calculate POR from start of state 3 s1=2*122;
s2(i,j)=sum(TL(1:(p.Es),i,j))+counter3_PO(ii-1,i,j);
TL(ii,i,j)=length(T);
St2_OCR(i,j)=mean(Jv(122:244,p.iCIV,i));
St2_dPsi(i,j)=mean(Xv(122:244,p.idPsi,i));
St2_NADH(i,j)=mean(Xv(122:244,p.iNADHm,i));
St2_NAD(i,j)=mean(Xv(122:244,p.iNADm,i));
St2_CytCred(i,j)=mean(Xv(122:244,p.iCytCred,i));
St2_CytCoxi(i,j)=mean(Xv(122:244,p.iCytCoxi,i));
St2_UQH2(i,j)=mean(Xv(122:244,p.iUQH2m,i));
St2_UQ(i,j)=mean(Xv(122:244,p.iUQm,i));

%% Plot
% cl =['r','g','b','c','m'];
% %%% oCR fluxes
% figure(1); subplot(3,2,i); % OCR dynamic
% p.sp=3; % start of plot 
% OCR(:,i)=movmean(Jv(p.sp:end,p.iCIV,i),5); 
% % plot(Tv(p.sp:end,i),Jv(p.sp:end,p.iCIV,i)); hold on
% plot(Tv(p.sp:end,i,j),OCR(:,i)); hold on
% if i==1; title('PM JO2'); elseif i==2; title('GM JO2');
% elseif i==3; title('AM JO2'); elseif i==4; title('Suc JO2');
% elseif i==5; title('Suc+Rot JO2'); end
% 
% figure(2); subplot(3,2,i) % dPsi dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.idPsi,i)); hold on 
% if i==1; title('PM \Delta\Psi'); elseif i==2; title('GM \Delta\Psi');
% elseif i==3; title('AM \Delta\Psi'); elseif i==4; title('Suc \Delta\Psi');
% elseif i==5; title('Suc+Rot \Delta\Psi'); end
% 
% figure(3); subplot(3,2,i) % ADPe dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iADPe,i)); hold on
% plot(1/60*s2(i,j),c2,'o'); hold on
% if i==1; title('PM ADPe'); elseif i==2; title('GM ADPe');
% elseif i==3; title('AM ADPe'); elseif i==4; title('Suc ADPe');
% elseif i==5; title('Suc+Rot ADPe'); end
% 
% figure(4); subplot(3,2,i) % O2 dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iO2m,i)); hold on   
% if i==1; title('PM O2m'); elseif i==2; title('GM O2m');
% elseif i==3; title('AM O2m'); elseif i==4; title('Suc O2m');
% elseif i==5; title('Suc+Rot O2m'); end
% 
% figure(5); subplot(3,2,i) % ADPm dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iADPm,i)); hold on 
% if i==1; title('PM ADPm'); elseif i==2; title('GM ADPm');
% elseif i==3; title('AM ADPm'); elseif i==4; title('Suc ADPm');
% elseif i==5; title('Suc+Rot ADPm'); end
% 
% figure(6); subplot(3,2,i) % ATPm dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iATPm,i)); hold on 
% if i==1; title('PM ATPm'); elseif i==2; title('GM ATPm');
% elseif i==3; title('AM ATPm'); elseif i==4; title('Suc ATPm');
% elseif i==5; title('Suc+Rot ATPm'); end
% 
% figure(7); subplot(3,2,i) % ATPe dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iATPe,i)); hold on   
% if i==1; title('PM ATPe'); elseif i==2; title('GM ATPe');
% elseif i==3; title('AM ATPe'); elseif i==4; title('Suc ATPe');
% elseif i==5; title('Suc+Rot ATPe'); end
% 
% figure(8); subplot(3,2,i) % ATPe dynamic
% if i==1; title('PM ANT'); elseif i==2; title('GM ANT');
% elseif i==3; title('AM ANT'); elseif i==4; title('Suc ANT');
% elseif i==5; title('Suc+Rot ANT'); end

end % i substrate for-loop
end % j for leak factor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot 1 ADP OCR
figure(51); 
cl =['r','g','b','c','m'];
p.sp=3;
for i =p.ISub:1:p.NSub
     OCR(:,i)=movmean(Jv(p.sp:end,p.iCIV,i),5);
     plot(Tv(p.sp:end,i),OCR(:,i),cl(i),'linewidth',linewidth); hold on
     xlabel('Time (min)');     %ylabel({'J_O_2 (nnmol/min/mg)'});
     set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
     box off
     hold on
end
% lgd1=legend({'PM','GM','AM','SUC','SUC+ROT'},'Location','northwest'); legend boxoff;
% lgd1.NumColumns = 1;
hold off
ax=gca; ax.XLim=[0 inf];

%% Plot 1 ADP redox ratios vs HLeak
cl =['r','g','b','c','m'];
set(figure(52),'Units','inches','Position',Position1,'PaperPosition',Position1);
%%% NADH Ratio
xleak =100*HLF;
Pkvx=[ADP_add]*1e6; 
for i=p.ISub:1:p.NSub
NADHRp(i,:)=(Xmin_NADH(4,i,1:length(HLF))./(Xmin_NADH(4,i,1:length(HLF))+Xmax_NADH(4,i,1:length(HLF)))); 
St2_NADHRp(i,:)=(St2_NADH(i,1:length(HLF))./(St2_NADH(i,1:length(HLF))+St2_NAD(i,1:length(HLF)))); 
plot(xleak(:),St2_NADHRp(i,:),cl(i),'linewidth',linewidth); hold on;
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
xlabel('Relative proton leak');   xtickformat('percentage');   
ylabel('NADH Ratio')
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
hold on
end
% lgd1=legend({'PM','GM','AM','SUC','SUC+ROT'},'Location','southeast'); legend boxoff;
% lgd1.NumColumns = 1;
box off;   hold off
set(gcf,'color','w');   set(gca,'Fontsize',text_size)
xlim([100 900]); xticks([100:200:900])
ylim([0 1]); yticks([0:.2:1])

%%% QH2 Ratio
set(figure(53),'Units','inches','Position',Position1,'PaperPosition',Position1);
xleak =100*HLF;
Pkvx=[ADP_add]*1e6; 
for i=p.ISub:1:p.NSub
if i==1 || i==2 || i==3
QH2Rp(i,:)=(Xmax_QH2(4,i,1:length(HLF))./(Xmax_QH2(4,i,1:length(HLF))+Xmin_QH2(4,i,1:length(HLF))));
St2_UQH2p(i,:)=(St2_UQH2(i,1:length(HLF))./(St2_UQH2(i,1:length(HLF))+St2_UQ(i,1:length(HLF)))); 
plot(xleak(:),St2_UQH2p(i,:),cl(i),'linewidth',linewidth)
elseif i==4 || i==5 
QH2Rp(i,:)=(Xmin_QH2(4,i,1:length(HLF))./(Xmax_QH2(4,i,1:length(HLF))+Xmin_QH2(4,i,1:length(HLF))));
St2_UQH2p(i,:)=(St2_UQH2(i,1:length(HLF))./(St2_UQH2(i,1:length(HLF))+St2_UQ(i,1:length(HLF)))); 
plot(xleak(:),St2_UQH2p(i,:),cl(i),'linewidth',linewidth)
end
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlabel('Relative proton leak');   xtickformat('percentage');   
ylabel('UQH2 Ratio')
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
hold on
end
box off;   hold off
set(gcf,'color','w');   set(gca,'Fontsize',text_size)
xlim([100 900]); xticks([100:200:900])
ylim([0 .2]); yticks([0:.05:.2])

%%% Cytcred Ratio
set(figure(54),'Units','inches','Position',Position1,'PaperPosition',Position1);
xleak =100*HLF;
Pkvx=[ADP_add]*1e6; 
for i=p.ISub:1:p.NSub
if i==1 || i==2 || i==3
CytcRp(i,:)=(Xmax_Cytc(4,i,1:length(HLF))./(Xmax_Cytc(4,i,1:length(HLF))+Xmin_Cytc(4,i,1:length(HLF))));
St2_CytCp(i,:)=(St2_CytCred(i,1:length(HLF))./(St2_CytCred(i,1:length(HLF))+St2_CytCoxi(i,1:length(HLF)))); 
plot(xleak(:),St2_CytCp(i,:),cl(i),'linewidth',linewidth)
elseif i==4 || i==5 
CytcRp(i,:)=(Xmin_Cytc(4,i,1:length(HLF))./(Xmax_Cytc(4,i,1:length(HLF))+Xmin_Cytc(4,i,1:length(HLF))));
St2_CytCp(i,:)=(St2_CytCred(i,1:length(HLF))./(St2_CytCred(i,1:length(HLF))+St2_CytCoxi(i,1:length(HLF)))); 
plot(xleak(:),St2_CytCp(i,:),cl(i),'linewidth',linewidth)
end
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlabel('Relative proton leak');   xtickformat('percentage');   
ylabel('Cytc Ratio')
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
hold on
end
box off;   hold off
set(gcf,'color','w');   set(gca,'Fontsize',text_size)
xlim([100 900]); xticks([100:200:900])
ylim([0 .2]); yticks([0:.05:.2])

%%% dPsi
set(figure(55),'Units','inches','Position',Position1,'PaperPosition',Position1);
xleak =100*HLF(1:1:length(HLF));
Pkvx=[ADP_add]*1e6; 
for i=p.ISub:1:p.NSub
dPsip(i,:)=dPsi_min(4,i,1:length(HLF)); hold on
plot(xleak(:),St2_dPsi(i,1:length(HLF)),cl(i),'linewidth',linewidth); hold on
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlabel('Relative proton leak');   xtickformat('percentage');   ylabel('\Delta\Psi (mV)')
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
hold on
end
box off;   hold off
set(gcf,'color','w');   set(gca,'Fontsize',text_size)
xlim([100 900]); xticks([100:200:900])
ylim([120 180]); yticks([120:20:180])

%%% RCI
set(figure(56),'Units','inches','Position',Position1,'PaperPosition',Position1);
xleak =100*HLF(1:1:length(HLF));
Pkvx=[ADP_add]*1e6; 
for i=p.ISub:1:p.NSub
RCIp(i,:)=RCI(4,i,1:length(HLF));
plot(xleak(:),RCIp(i,:),cl(i),'linewidth',linewidth)
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlabel('Relative proton leak');   xtickformat('percentage');   
ylabel('RCI')
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
hold on
end
box off;   hold off
set(gcf,'color','w');   set(gca,'Fontsize',text_size)
xlim([100 900]); xticks([100:200:900])
ylim([0 6]); yticks([0:2:6])
