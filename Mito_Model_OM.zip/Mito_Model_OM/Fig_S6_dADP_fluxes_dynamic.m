%% dADP flux simulations 
%% Clear worksapce
close all; clc;
clear all; 
warning off; 
format long; 
tic % measure elapsed time 
%% run the model
run Driver_AllFig; 
run Read_Condt
%% plot settings
Position51= [.05,.05, 11, 13];
Position66= [.05,.05, 16, 12];
text_size= .9*12; 
linewidth= 1.5; 
% for NADH linked substrates (PM,GM,AM) p.ISub=1; p.NSub=3; 
p.ISub=5; % initial substrate 
p.NSub=5; % number of substrates  and last substrate
% for FADH2-linked substrates p.ISub=4; p.NSub=5; 
% p.ISub=4; % initial substrate 
% p.NSub=5; % number of substrates  and last substrate
Es=3; St=10; Ed=length(Tv)-St; % fluxes 
xst=0; xend=30; % time
% ylim auto
% ax=gca;     ax.YLim=[-inf inf];
%% remove outliers from dynamic data 
for i=p.ISub:1:p.NSub
for j=1:1:p.NPar
mx(j,1)=max(Jv(st:Ed,j,i)); % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first');  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+10,j,i); % substitiute the max with the previous value
mn(j,1)=min(Jv(st:Ed,j,i)); % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mn(j,1),1,'first');  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+10,j,i); % substitiute the max with the previous value
end
mx(j,1)=max(Jv(st:Ed,j,i)); % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first');  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+10,j,i); % substitiute the max with the previous value
mx(j,1)=max(Jv(st:Ed,j,i)); % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first');  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+10,j,i); % substitiute the max with the previous value
mx(j,1)=max(Jv(st:Ed,j,i)); % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first');  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+10,j,i); % substitiute the max with the previous value
mx(j,1)=max(Jv(st:Ed,j,i)); % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first');  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+10,j,i); % substitiute the max with the previous value
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% static flux 
%%% maximum of flux at the last ADP addition 
a=.9;
sub_names =[{'PM'};{'GM'};{'AM'};{'SUC'};{'SUC+ROT'}];
set(figure(60),'Units','inches','Position',Position51,'PaperPosition',Position51); 
for i=p.ISub:1:p.NSub
subplot(p.NSub,1,i); 
b=bar([JPk(3,:,i)' JPk(8,:,i)']);
if i ==1
TestL={'State 2','State 3'};
legend(TestL,'Location','northwest'); legend boxoff;
end
ylabel({'Fluxes',' (nmol/min/mg)'});
set(gca,'xtick',1:24,'xticklabel',{'PDH','CITS','IDH','AKGDH','SCAS','NDK','FH','MDH','GOT','CI','CII',...
    'CIII','CIV','CV','PYRH','GLUH','DCCS','DCCM','TCC','OME','GAE','ANT','PIC','HLeak'});  xtickangle(45)
title(sub_names(i));
set(gcf,'color','w');   set(gca,'Fontsize',a*text_size); box off;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% dynamic flux 
%% PDH
set(figure(61),'Units','inches','Position',Position66,'PaperPosition',Position66); % figure setting
subplot(5,5,1)
cl =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iPDH,i),cl(i),'linewidth',linewidth) 
    hold on
end
xlabel('Time (min)');     %ylabel({'J_P_D_H','(nmol/min/mg)'}); 
ylabel({'J_P_D_H'}); 
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off; 
if i==1 || i==2 || i==3
Mny=0; Mxy=30; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=.06; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% CITS
subplot(5,5,2)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iCITS,i),c1(i),'linewidth',linewidth);  
    hold on
end
xlabel('Time (min)');     ylabel({'J_C_I_T_S'}); %ylabel({'J_C_I_T_S','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off; 
if i==1 || i==2 || i==3
Mny=0; Mxy=30; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=.9; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% ICDH
subplot(5,5,3)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iICDH,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_I_C_D_H'}); %ylabel({'J_I_C_D_H','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off; 
if i==1 || i==2 || i==3
Mny=0; Mxy=3; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=15; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% AKGDH
subplot(5,5,4)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iAKGDH,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_A_K_G_D_H'}); %ylabel({'J_A_K_G_D_H','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   
if i==1 || i==2 || i==3
Mny=0; Mxy=30; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=.9; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% SCAS
subplot(5,5,5)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iSCAS,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_S_C_A_S'}); %ylabel({'J_S_C_A_S','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   %hold off 
if i==1 || i==2 || i==3
Mny=0; Mxy=30; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-3; Mxy=12; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% NDK
subplot(5,5,6)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iNDK,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     %ylabel({'J_N_D_K','(nmol/min/mg)'}); 
ylabel({'J_N_D_K'}); 
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   
if i==1 || i==2 || i==3
Mny=0; Mxy=30; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-5; Mxy=25; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% SDH
subplot(5,5,7)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iCII,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_S_D_H'}); %ylabel({'J_S_D_H','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
ax=gca;     ax.YLim=[-inf inf];
box off;   hold off
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
if i==1 || i==2 || i==3 %*
Mny=-15; Mxy=15; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=60; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% FH
subplot(5,5,8)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iFH,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_F_H'}); %ylabel({'J_F_H','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
ax=gca;     ax.YLim=[-inf inf];
box off;   hold off
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   
if i==1 || i==2 || i==3
Mny=-15; Mxy=15; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=60; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% MDH
subplot(5,5,9)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iMDH,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_M_D_H'}); %ylabel({'J_M_D_H','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   
if i==1 || i==2 || i==3
Mny=0; Mxy=30; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-3; Mxy=3; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% GOT
subplot(5,5,10)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iGOT,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_G_O_T'}); %ylabel({'J_G_O_T','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   %hold off
if i==1 || i==2 || i==3
Mny=-21; Mxy=0; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-.03e-5; Mxy=.06e-5; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% CI
subplot(5,5,11)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iCI,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     %ylabel({'J_C_I','(nmol/min/mg)'}); 
ylabel({'J_C_I'}); 
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   %hold off
if i==1 || i==2 || i==3
Mny=-30; Mxy=60; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-30; Mxy=60; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% CII
subplot(5,5,12)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iCII,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');    ylabel({'J_C_I_I'}); % ylabel({'J_C_I_I','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   %hold off  
if i==1 || i==2 || i==3
Mny=-15; Mxy=15; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=60; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% CIII
subplot(5,5,13)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iCIII,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_C_I_I_I'}); %ylabel({'J_C_I_I_I','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   %hold off
if i==1 || i==2 || i==3
Mny=0; Mxy=60; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=60; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% CIV
subplot(5,5,14)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iCIV,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_C_I_V'}); %ylabel({'J_C_I_V','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   %hold off  
if i==1 || i==2 || i==3
Mny=0; Mxy=60; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5 %*
Mny=0; Mxy=60; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% CV
subplot(5,5,15)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iCV,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_C_V'}); %ylabel({'J_C_V','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   %hold off  
if i==1 || i==2 || i==3
Mny=0; Mxy=150; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=90; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% TRANSPORTERS 
%% PYRH
subplot(5,5,16)
c1 =['r','g','b','c','m'];
mx=max(Jv(st:Ed,p.iPYRH,1)); % find the maximum of PYRH flux
Ix=find(Jv(st:Ed,p.iPYRH,1)==mx,1,'first');  % find the correspondind index 
Jv(Ix,p.iPYRH,1)=Jv(Ix-1,p.iPYRH,1); % subsstitiute the max with the previous value
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iPYRH,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     %ylabel({'J_P_Y_R_H','(nmol/min/mg)'}); 
ylabel({'J_P_Y_R_H'}); 
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   %hold off
if i==1 || i==2 || i==3
Mny=0; Mxy=30; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-.01; Mxy=.05; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% GLUH
subplot(5,5,17)
c1 =['r','g','b','c','m'];
mx=max(Jv(st:Ed,p.iGLUH,2)); % find the maximum of GLUH flux
Ix=find(Jv(st:Ed,p.iGLUH,2)==mx,1,'first');  % find the correspondind index 
Jv(Ix,p.iGLUH,2)=Jv(Ix-1,p.iGLUH,2); % subsstitiute the max with the previous value
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iGLUH,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_G_L_U_H'}); %ylabel({'J_G_L_U_H','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   %hold off 
if i==1 || i==2 || i==3
Mny=-.06; Mxy=.0; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-.01e-4; Mxy=.02e-4; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% DCC1;    SUC-Pi
subplot(5,5,18)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iDCC1,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_D_C_C_S'}); %ylabel({'J_S_U_C_P_i','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]);  
box off;   %hold off  
if i==1 || i==2 || i==3
Mny=-25; Mxy=5; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5 %*
Mny=0; Mxy=60; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% DCC2:     MAL-Pi
subplot(5,5,19)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iDCC2,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_D_C_C_M'}); %ylabel({'J_M_A_L_P_i','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   
if i==1 || i==2 || i==3
Mny=-30; Mxy=90; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5 %*
Mny=-50; Mxy=10; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% TCC:  MAL-CIT  
subplot(5,5,20)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iTCC,i),c1(i),'linewidth',linewidth); 
    hold on
end

xlabel('Time (min)');     ylabel({'J_T_C_C'}); %ylabel({'J_T_C_C','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   %hold off 
if i==1 || i==2 || i==3
Mny=0; Mxy=30; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-.02; Mxy=.01; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% OME: Aspartate-Malate
subplot(5,5,21)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iOME,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     %ylabel({'J_O_M_E','(nmol/min/mg)'}); 
ylabel({'J_O_M_E'}); 
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]);  
box off;   %hold off 
if i==1 || i==2 || i==3
Mny=0; Mxy=15; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-.1; Mxy=.2; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% AGE: HGLU-ASP
subplot(5,5,22)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iGAE,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_G_A_E'}); %ylabel({'J_G_A_E','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]);  
box off;   %hold off  
if i==1 || i==2 || i==3
Mny=0; Mxy=24; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-.2e-5; Mxy=.1e-5; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% ANT
subplot(5,5,23)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iANT,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');    ylabel({'J_A_N_T'}); % ylabel({'J_A_N_T','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   %hold off 
if i==1 || i==2 || i==3
Mny=0; Mxy=180; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=150; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% PIC
subplot(5,5,24)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iPIC,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_P_I_C'}); %ylabel({'J_P_I_C','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   %hold off  
if i==1 || i==2 || i==3
Mny=0; Mxy=150; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=90; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% HLEAK
subplot(5,5,25)
c1 =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
    plot(Tv(St:Ed),Jv(St:Ed,p.iHLEAK,i),c1(i),'linewidth',linewidth); 
    hold on
end
xlabel('Time (min)');     ylabel({'J_H_L_E_A_K'}); %ylabel({'J_H_L_E_A_K','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   %hold off   
if i==1 || i==2 || i==3
Mny=0; Mxy=180; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=150; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end

