%% clear workspace % for CIV flux 
clear all
close all
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% declare variables 
run Read_Condt
%% load param and data
% data coloumns indicate: [PM GM AM Suc SucRot]
JO2_Pkd=[data.JO2_Pk(:,1) data.JO2_Pk(:,2) data.JO2_Pk(:,3) data.JO2_Pk(:,4) data.JO2_Pk(:,5)]; % nM
JO2_Pk_Err=[data.JO2_Pk_Err(:,1) data.JO2_Pk_Err(:,2) data.JO2_Pk_Err(:,3) data.JO2_Pk_Err(:,4) data.JO2_Pk_Err(:,5)]; % nM

%% substrates and ADP additions 
PYR_index=[1 0 0 0 0];
GLU_index=[0 1 0 0 0];
aKG_index=[0 0 1 0 0];
MAL_index=[1 1 1 0 0];
SUC_index=[0 0 0 1 1];
ADP_add=[0 25 50 75 100 150 250]*1e-6; p.ADPL=length(ADP_add); % uM
options = odeset('NonNegative',[1:p.NOde]); % concentrations of the state variables should be positive
for i=p.ISub:1:p.NSub
X0=ICs(p); p_tem=p; 
%%% solving ODEs and calculating state variables 
T0=0; jj=1; p.Es=3; % extra states 
cc=1;
if i==1 
   p.time=2*[1, .5, .5, .4, .7, .8, 1.0, 1.25, 2,1]';
elseif i==2 || i==3 
    p.time=2.5*[1, .5, .5, .5, .9, 1, 1.25, 1.75, 3,1]';
elseif i==4 || i==5
   p.time=3.75*[1, .5, .5, .5, .5, .6, .8, 1, 2,1]';  
end
for ii=1:1:p.ADPL+p.Es % ii=1: add mito, ii=2: add substrate, ii=3: add Rot i=5, ii=4-9 add 6 doses of ADP
    %%% Substrate addition 
    if ii==p.Es-1
        X0(p_tem.iMALe)=cc*MAL_index(i)*2.5e-3; % mM
        X0(p_tem.iPYRe)=cc*PYR_index(i)*5e-3; % mM
        X0(p_tem.iGLUe)=cc*GLU_index(i)*5e-3; % mM
        X0(p_tem.iaKGe)=cc*aKG_index(i)*5e-3; % mM
        X0(p_tem.iSUCe)=cc*SUC_index(i)*10e-3; % mM
    end
    if i == 5 && ii==p.Es % Rot addition
        p_tem.ini_VTmax(p.iCI)=0*p_tem.ini_VTmax(p.iCI); % inhibit CI
    end 

    %%% ADP addition
    if ii>=p.Es && ii~=p.ADPL+p.Es   
        X0(p_tem.iADPe)=X0(p.iADPe)+ADP_add(jj);
        jj=jj+1;
    end
    %%% Solving ODEs
    tspan=[T0:p.tstep:(T0+p.time(ii,1))];
    [T,X] = ode15s(@ODEs, tspan, X0, options, p_tem);     
    T0=T(end,:);       X0=X(end,:);  % redefining initial values for the next time periode 
    Tc(ii,i)={T};      Xc(ii,i)={X};  CO2(ii,i)=1e3*X(end,p.iO2m);
    %%% Calculating fluxes
    for zz=1:1:length(T) 
        J(zz,:,i)=Fluxes(X(zz,:),p_tem);        
    end
    Jc(ii,i)={J(1:zz,:,i)};

    %%% finding peaks of state 3 for ODEs
   if ii<p.Es || ii==p.ADPL+p.Es
        XPk(ii,:,i)=mean(Xc{ii,i}); 
   elseif ii>=p.Es || ii~=p.ADPL+p.Es
       if  i==4; st=15; else; st=1; end % for state 2 and Suc start from higher values    
        XPk(ii,:,i)=max(Xc{ii,i});
        Xmin(ii,:,i)=min(Xc{ii,i});
   end

   %%% finding peaks of state 3 for fluxes
   for s=1:p.NPar
   if ii<p.Es || ii==p.ADPL+p.Es
        JPk(ii,s,i)=mean(J(2:end,s,i));  % returns mean of each column   
        HPk(ii,i)=mean(J(2:end,s,i));
   elseif ii>=p.Es || ii~=p.ADPL+p.Es
       if  i==4; st=15; else; st=1; end % for state 2 and Suc start from higher values    
        JPk(ii,s,i)=max(J(st:end,s,i)); % returns max of each column 
        HPk(ii,i)=.5*max(J(st:end,s,i)); 
        RCI(ii-p.Es+1,i)=JPk(ii,p.iCIV,i)/JPk(p.Es,p.iCIV,i); % calculate RCI
        POR(ii-p.Es+1,i)=-1e3*(ADP_add(ii-p.Es+1)/2/(CO2(ii,i)-CO2(ii-1,i)));
   end
   end

end % ii time protocol for-loop
if i==1 
% storing cell variables in vectors 
Tv13(:,i)=        [Tc{1,i};   Tc{2,i};    Tc{3,i};    Tc{4,i};    Tc{5,i};    Tc{6,i};    Tc{7,i};    Tc{8,i};    Tc{9,i};];
Xv13(:,:,i)=1e0*  [Xc{1,i};   Xc{2,i};    Xc{3,i};    Xc{4,i};    Xc{5,i};    Xc{6,i};    Xc{7,i};    Xc{8,i};    Xc{9,i};]; % M
Jv13(:,:,i)=1e9*  [Jc{1,i};   Jc{2,i};    Jc{3,i};    Jc{4,i};    Jc{5,i};    Jc{6,i};    Jc{7,i};    Jc{8,i};    Jc{9,i};]; % nmol/min/mg mito
elseif i==2 || i==3
% storing cell variables in vectors 
Tv25(:,i)=        [Tc{1,i};   Tc{2,i};    Tc{3,i};    Tc{4,i};    Tc{5,i};    Tc{6,i};    Tc{7,i};    Tc{8,i};    Tc{9,i};];
Xv25(:,:,i)=1e0*  [Xc{1,i};   Xc{2,i};    Xc{3,i};    Xc{4,i};    Xc{5,i};    Xc{6,i};    Xc{7,i};    Xc{8,i};    Xc{9,i};]; % M
Jv25(:,:,i)=1e9*  [Jc{1,i};   Jc{2,i};    Jc{3,i};    Jc{4,i};    Jc{5,i};    Jc{6,i};    Jc{7,i};    Jc{8,i};    Jc{9,i};]; % nmol/min/mg mito
elseif i==4 || i==5
Tv(:,i)=        [Tc{1,i};   Tc{2,i};    Tc{3,i};    Tc{4,i};    Tc{5,i};    Tc{6,i};    Tc{7,i};    Tc{8,i};    Tc{9,i};];
Xv(:,:,i)=1e0*  [Xc{1,i};   Xc{2,i};    Xc{3,i};    Xc{4,i};    Xc{5,i};    Xc{6,i};    Xc{7,i};    Xc{8,i};    Xc{9,i};]; % M
Jv(:,:,i)=1e9*  [Jc{1,i};   Jc{2,i};    Jc{3,i};    Jc{4,i};    Jc{5,i};    Jc{6,i};    Jc{7,i};    Jc{8,i};    Jc{9,i};]; % nmol/min/mg mito
end
if i==4 || i==5 
    JPk(9,:,i)=JPk(8,:,i); 
    XPk(9,:,i)=XPk(8,:,i); 
    RCI(7,i)=RCI(6,i); 
    POR(7,i)=POR(6,i); 
end

%% plots
% %%% oCR fluxes
% figure(1); subplot(3,2,i); % OCR dynamic
% p.sp=3; % start of plot 
% if i==1 
% OCR13(:,i)=movmean(Jv13(p.sp:end,p.iCIV,i),5); 
% % plot(Tv(p.sp:end,i),Jv(p.sp:end,p.iCIV,i)); hold on
% plot(Tv13(p.sp:end,i),OCR13(:,i)); hold on
% elseif i==2 || i==3
% OCR25(:,i)=movmean(Jv25(p.sp:end,p.iCIV,i),5); 
% % plot(Tv(p.sp:end,i),Jv(p.sp:end,p.iCIV,i)); hold on
% plot(Tv25(p.sp:end,i),OCR25(:,i)); hold on
% elseif i==4 || i==5
% OCR(:,i)=movmean(Jv(p.sp:end,p.iCIV,i),5); 
% % plot(Tv(p.sp:end,i),Jv(p.sp:end,p.iCIV,i)); hold on
% plot(Tv(p.sp:end,i),OCR(:,i)); hold on
% end
% if i==1; title('PM JO2'); elseif i==2; title('GM JO2');
% elseif i==3; title('AM JO2'); elseif i==4; title('Suc JO2');
% elseif i==5; title('Suc+Rot JO2'); end
% 
% figure(2); subplot(3,2,i) % POR
% Pkvx=[ADP_add]*1e6;
% plot(Pkvx,POR(:,i)); hold on
% % xlim([0 Tv(end,1)]);  ylim([0 1]*1e-7);   
% if i==1; title('PM POR'); elseif i==2; title('GM POR');
% elseif i==3; title('AM POR'); elseif i==4; title('Suc POR');
% elseif i==5; title('Suc+Rot POR'); end

end % i substrate for-loop

