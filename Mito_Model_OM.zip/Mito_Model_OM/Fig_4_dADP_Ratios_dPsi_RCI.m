%% Clear worksapce
close all; clc;
clear all; 
warning off; 
format long; 
tic % measure elapsed time 
%% run the model
run Driver_Ratio;
%% plot settings
Position15= [.5,.5, 20, 4];
text_size= 70; 
title_size= 70;
linewidth= 10; 
MarkerSize= 10; 
MarkerSizeErr= 12;
Position1= [.05,.05, 14, 12];
%% static simulations of redox ratios 
Pkvx=[ADP_add]*1e6;
cl =['r','g','b','c','m'];
p.Es=3;

%%% NADH/NADH+NAD
set(figure(41),'Units','inches','Position',Position1,'PaperPosition',Position1);
for i = p.ISub:1:p.NSub  
plot(Pkvx,(Xmin(p.Es:9,p.iNADHm,i)./(Xmin(p.Es:9,p.iNADHm,i)+XPk(p.Es:9,p.iNADm,i))),cl(i),'linewidth',linewidth) 
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold')
hold on
end
box off;    hold off
% lgd1=legend({'PM','GM','AM','SUC','SUC+ROT'},'Location','southeast'); legend boxoff;
% lgd1.NumColumns = 1;
xlabel('ADP (\muM)');   
ylabel('NADH Ratio')
xlim([0 250]);   xticks([0:50:250])   
ylim([0 1]);   yticks([0:.2:1])

%%% UQH2
set(figure(42),'Units','inches','Position',Position1,'PaperPosition',Position1);
for i =p.ISub:1:p.NSub
if i==1 || i==2 || i==3
plot(Pkvx,(XPk(p.Es:9,p.iUQH2m,i)./(XPk(p.Es:9,p.iUQH2m,i)+Xmin(p.Es:9,p.iUQm,i))),cl(i),'linewidth',linewidth) 
elseif i==4 || i==5 
plot(Pkvx,(Xmin(p.Es:9,p.iUQH2m,i)./(Xmin(p.Es:9,p.iUQH2m,i)+XPk(p.Es:9,p.iUQm,i))),cl(i),'linewidth',linewidth) 
end
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold')
hold on
end
box off;    hold off
xlabel('ADP (\muM)');
ylabel('UQH2 Ratio')
xlim([0 250]);   xticks([0:50:250])   

%%% CytCred
set(figure(43),'Units','inches','Position',Position1,'PaperPosition',Position1);
for i =p.ISub:1:p.NSub
if i==1 || i==2 || i==3
plot(Pkvx,(XPk(p.Es:9,p.iCytCred,i)./(XPk(p.Es:9,p.iCytCred,i)+Xmin(p.Es:9,p.iCytCoxi,i))),cl(i),'linewidth',linewidth) 
elseif i==4 || i==5 
plot(Pkvx,(Xmin(p.Es:9,p.iCytCred,i)./(Xmin(p.Es:9,p.iCytCred,i)+XPk(p.Es:9,p.iCytCoxi,i))),cl(i),'linewidth',linewidth) 
end
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold')
hold on
end
box off;    hold off
xlabel('ADP (\muM)'); 
ylabel('CytC Ratio')
xlim([0 250]);   xticks([0:50:250])    
ylim([0 .2]);   yticks([0:.05:.2])

%%% dPsi
set(figure(44),'Units','inches','Position',Position1,'PaperPosition',Position1);
for i =p.ISub:1:p.NSub
plot(Pkvx,Xmin(3:9,p.idPsi,i),cl(i),'linewidth',linewidth) 
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold')
hold on
end
box off;    hold off
xlabel('ADP (\muM)');
ylabel('\Delta\Psi (mV)')
xlim([0 250]);   xticks([0:50:250]);
ylim([120 200]);    yticks([100:20:200])

%%% RCI
set(figure(45),'Units','inches','Position',Position1,'PaperPosition',Position1);
for i =p.ISub:1:p.NSub
plot(Pkvx,RCI(1:end,i),cl(i),'linewidth',linewidth) 
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold')
hold on
end
box off;    hold off
xlabel('ADP (\muM)');
ylabel('RCI')
xlim([0 250]);   xticks([0:50:250]);
ylim([0 6]);    yticks([0:2:6])