%% dADP OCR model simulations 
%% Clear worksapce
close all; clc;
clear all; 
warning off; 
format long; 
tic % measure elapsed time 
%% run the model
run Driver_AllFig; 
run Read_Condt
%% plot settings
Position1= 2*[.5,.5, 5.5, 4.5];
text_size= 40;
linewidth= 6;
MarkerSizeErr= 10;
%% read data
% data rows indicate: [PM GM AM Suc SucRot]
JO2_Pkd=[data.JO2_Pk(:,1) data.JO2_Pk(:,2) data.JO2_Pk(:,3) data.JO2_Pk(:,4) data.JO2_Pk(:,5)]; % nM
JO2_Pkd_Err=[data.JO2_Pk_Err(:,1) data.JO2_Pk_Err(:,2) data.JO2_Pk_Err(:,3) data.JO2_Pk_Err(:,4) data.JO2_Pk_Err(:,5)]; % nM
ADP_add=[0 25 50 75 100 150 250]*1e-6;
St=50; Ed=length(Tv)-St;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% data rep OCR dynamic with different ADP additions nmol/min/mg mito
set(figure(21),'Units','inches','Position',Position1,'PaperPosition',Position1);
cl =['r','g','b','c','m'];
for i =p.ISub:1:p.NSub
     plot(data.timev(1:length(data.JO2_nmol_TC(:,i))),data.JO2_nmol_TC(:,i),cl(i),'Linestyle','-.','linewidth',linewidth); 
     xlabel('Time (min)');     ylabel({'J_O_2 (nmol/min/mg)'});
     set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
     hold on
end
set(gcf,'color','w');  set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold'); hold on
% lgd1=legend({'PM','GM','AM','SUC','SUC+ROT'},'Location','northwest'); legend boxoff;
% lgd1.NumColumns = 1;
box off;   hold off
ax=gca; ax.XLim=[0 inf];
xlim([0 20]);  xticks([0:5:20])
ylim([0 200]);  yticks([0:50:200])

%% Simulation OCR dynamic with different ADP additions 
set(figure(22),'Units','inches','Position',Position1,'PaperPosition',Position1);
cl =['r','g','b','c','m'];
p.sp=3; 
for i =p.ISub:1:p.NSub
     OCR(:,i)=movmean(Jv(p.sp:end,p.iCIV,i),5);
     plot(Tv(p.sp:end,i),OCR(:,i),cl(i),'linewidth',linewidth); 
%      plot(Tv(p.sp:end,i),Jv(p.sp:end,p.iCIV,i),cl(i),'linewidth',linewidth)
     xlabel('Time (min)');     ylabel({'J_O_2 (nnmol/min/mg)'});
     set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
     hold on
end
set(gcf,'color','w');  set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold'); 
box off;   hold off
xlim([0 20]);  xticks([0:5:20])
ylim([0 200]);  yticks([0:50:200])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Simulation OCR peaks fitting to data with error bars 
set(figure(23),'Units','inches','Position',Position1,'PaperPosition',Position1);
cl =['r','g','b','c','m'];
p.Es=3;
Pkvx=[ADP_add]*1e6; UCF=1e9;
for i=p.ISub:1:p.NSub
    plot(Pkvx,UCF*JPk(p.Es:9,p.iCIV,i),cl(i),'linewidth',linewidth); hold on
    errorbar(Pkvx, JO2_Pkd(:,i), JO2_Pkd_Err(:,i),cl(i),'Marker','o','MarkerSize',MarkerSizeErr,...
        'MarkerFaceColor',cl(i),'LineStyle','none','linewidth',1*linewidth);
end
set(gcf,'color','w');  set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold'); 
xlabel('ADP (\muM)');   %ylabel('J_O_2 (nmol/min/mg)')
box off;   hold off
xlim([0 250]); xticks([0:50:250])
ylim([0 200]); yticks([0:50:200])



