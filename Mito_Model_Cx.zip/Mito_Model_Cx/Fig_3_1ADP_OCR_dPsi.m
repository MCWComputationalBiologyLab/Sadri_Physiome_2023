%% clear workspace 
clear all
close all
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% declare variables 
run Read_Condt
%% plot settings
text_size= 46;
linewidth= 6;
Position1= 2*[.5,.5, 5.5, 4.5];
%% experimental condition
p.Ve=.3*5e-3; % buffer_Vol/mito_Vol .2 mg/mL
p.time=2*[1, .5, .5, 2.5 2]'; % mito, Sub, Sub+Rot
%% load data
% data coloumns indicate: [PM GM AM Suc SucRot]
JO2_1ADPd=[data.JO2_1ADP_nmol(:,1) data.JO2_1ADP_nmol(:,2) data.JO2_1ADP_nmol(:,3) data.JO2_1ADP_nmol(:,4) data.JO2_1ADP_nmol(:,5)]; % nM
dPsi_1ADPd=[data.dPsi_1ADP(:,1) data.dPsi_1ADP(:,2) data.dPsi_1ADP(:,3) data.dPsi_1ADP(:,4) data.dPsi_1ADP(:,5)]; % nM

%% substrates and ADP additions 
PYR_index=[1 0 0 0 0];
GLU_index=[0 1 0 0 0];
aKG_index=[0 0 1 0 0];
MAL_index=[1 1 1 0 0];
SUC_index=[0 0 0 1 1];
ADP_add=[0 100]*1e-6; p.ADPL=length(ADP_add); % uM
options = odeset('NonNegative',[1:p.NOde]); % concentrations of the state variables should be positive
for i=p.ISub:1:p.NSub 
X0=ICs(p); p_tem=p; 
%%% solving ODEs and calculating state variables 
T0=0; jj=1; p.Es=3; % extra states 
cc=1;
for ii=1:1:p.ADPL+p.Es % ii=1: add mito, ii=2: add substrate, ii=3: add Rot i=5, ii=4-9 add 6 doses of ADP
    %%% Substrate addition 
    if ii==p.Es-1
        X0(p_tem.iMALe)=cc*MAL_index(i)*2.5e-3; % mM
        X0(p_tem.iPYRe)=cc*PYR_index(i)*5e-3; % mM
        X0(p_tem.iGLUe)=cc*GLU_index(i)*5e-3; % mM
        X0(p_tem.iaKGe)=cc*aKG_index(i)*5e-3; % mM
        X0(p_tem.iSUCe)=cc*SUC_index(i)*10e-3; % mM
    end
    if i==5 && ii==p.Es % Rot addition
        p_tem.ini_VTmax(p.iCI)=0*p_tem.ini_VTmax(p.iCI); % inhibit CI
    end 
    %%% ADP addition
    if ii>=p.Es && ii~=p.ADPL+p.Es   
        X0(p_tem.iADPe)=X0(p.iADPe)+ADP_add(jj);
        jj=jj+1;
    end
    %%% Solving ODEs
    tspan=[T0:p.tstep:(T0+p.time(ii,1))];
    [T,X] = ode15s(@ODEs, tspan, X0, options, p_tem);     
    T0=T(end,:);       X0=X(end,:);  % redefining initial values for the next time periode 
    Tc(ii,i)={T};      Xc(ii,i)={X};  CO2(ii,i)=1e3*X(end,p.iO2m);
    %%% Calculating fluxes
    for zz=1:1:length(T) %length(tspan) %length(T)
        J(zz,:,i)=Fluxes(X(zz,:),p_tem);        
    end
    Jc(ii,i)={J(1:zz,:,i)};

    %%% finding peaks of state 3 for ODEs
   if ii<p.Es || ii==p.ADPL+p.Es
        XPk(ii,:,i)=mean(Xc{ii,i}); 
   elseif ii>=p.Es || ii~=p.ADPL+p.Es
       if  i==4; st=15; else; st=1; end % for state 2 and Suc start from higher values    
        XPk(ii,:,i)=max(Xc{ii,i});
        Xmin(ii,:,i)=min(Xc{ii,i});
   end

   %%% finding peaks of state 3 for fluxes
   for s=1:p.NPar
   if ii<p.Es || ii==p.ADPL+p.Es
        JPk(ii,s,i)=mean(J(2:end,s,i));  % returns mean of each column   
        HPk(ii,i)=mean(J(2:end,s,i));
   elseif ii>=p.Es || ii~=p.ADPL+p.Es
       if  i==4; st=15; else; st=1; end % for state 2 and Suc start from higher values    
        JPk(ii,s,i)=max(J(st:end,s,i)); % returns max of each column 
        HPk(ii,i)=.5*max(J(st:end,s,i)); 
        RCI(ii-p.Es+1,i)=JPk(ii,p.iCIV,i)/JPk(p.Es,p.iCIV,i); % calculate RCI
        POR(ii-p.Es+1,i)=-1e3*(ADP_add(ii-p.Es+1)/2/(CO2(ii,i)-CO2(ii-1,i)));
   end
   end

end % ii time protocol for-loop

% storing cell variables in vectors 
Tv(:,i)=        [Tc{1,i};   Tc{2,i};    Tc{3,i};    Tc{4,i};    Tc{5,i};]; % min
Xv(:,:,i)=1e0*  [Xc{1,i};   Xc{2,i};    Xc{3,i};    Xc{4,i};    Xc{5,i};]; % M
Jv(:,:,i)=1e9*  [Jc{1,i};   Jc{2,i};    Jc{3,i};    Jc{4,i};    Jc{5,i};]; % nmol/min/mg mito

%% Plot
% %%% OCR fluxes
% figure(1); subplot(3,2,i); % OCR dynamic
% p.sp=3; % start of plot 
% OCR(:,i)=movmean(Jv(p.sp:end,p.iCIV,i),5); 
% % plot(Tv(p.sp:end,i),Jv(p.sp:end,p.iCIV,i)); hold on
% plot(Tv(p.sp:end,i),OCR(:,i)); hold on
% % xlim([0 Tv(end,1)]);  ylim([0 1]*1e-7);   
% if i==1; title('PM JO2'); elseif i==2; title('GM JO2');
% elseif i==3; title('AM JO2'); elseif i==4; title('Suc JO2');
% elseif i==5; title('Suc+Rot JO2'); end
% 
% figure(2); subplot(3,2,i) % dPsi dynamic
% plot(Tv(p.sp:end,i),Xv(p.sp:end,p.idPsi,i)); hold on
% % xlim([0 Tv(end,1)]);  % ylim([0 1]*1e-7);   
% if i==1; title('PM \Delta\Psi'); elseif i==2; title('GM \Delta\Psi');
% elseif i==3; title('AM \Delta\Psi'); elseif i==4; title('Suc \Delta\Psi');
% elseif i==5; title('Suc+Rot \Delta\Psi'); end

end % i substrate for-loop

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot 1 ADP OCR sim
set(figure(31),'Units','inches','Position',Position1,'PaperPosition',Position1);
cl =['r','g','b','c','m'];
for i =p.ISub:1:p.NSub
     OCR(:,i)=movmean(Jv(p.sp:end,p.iCIV,i),5);
     plot(Tv(p.sp:end,i)-2,OCR(:,i),cl(i),'linewidth',linewidth); hold on
     xlabel('Time (min)');     ylabel({'J_O_2 (nmol/min/mg)'});
     set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
     box off;   hold on
end
% lgd1=legend({'PM','GM','AM','SUC','SUC+ROT'},'Location','northwest'); legend boxoff;
% lgd1.NumColumns = 1;
xlim([0 8]);  xticks([0:2:8])
ylim([0 200]);  yticks([0:50:200])

%% plot 1 ADP OCR data
set(figure(32),'Units','inches','Position',Position1,'PaperPosition',Position1);
cl =['r','g','b','c','m'];
for i =p.ISub:1:p.NSub
     plot(data.timev(1:length(JO2_1ADPd(p.sp:end,1)))-2,JO2_1ADPd(p.sp:end,i),cl(i),'Linestyle','-.','linewidth',linewidth); hold on
     xlabel('Time (min)');     ylabel({'J_O_2 (nmol/min/mg)'});
     set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
     box off;   hold on
end
xlim([0 8]);  xticks([0:2:8])
ylim([0 200]);  yticks([0:50:200])

%% plot 1 ADP dPsi sim
set(figure(33),'Units','inches','Position',Position1,'PaperPosition',Position1);
p.sp=120;
cl =['r','g','b','c','m'];
for i =p.ISub:1:p.NSub
     plot(Tv(p.sp:end,i)-2,Xv(p.sp:end,p.idPsi,i),cl(i),'linewidth',linewidth); hold on
     xlabel('Time (min)');     ylabel({'\Delta\Psi (mV)'});
     set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
     box off;   hold on
end
ylim([100 225]);  yticks([100:25:225])
xlim([0 8]);  xticks([0:2:8])

%% plot 1 ADP dPsi data
set(figure(34),'Units','inches','Position',Position1,'PaperPosition',Position1);
% subplot(1,4,4)
cl =['r','g','b','c','m']; p.sp=30;
for i =p.ISub:1:p.NSub
     plot(data.timev(1:681-p.sp,2)-2.2,dPsi_1ADPd(p.sp:680,i),cl(i),'Linestyle','-.','linewidth',linewidth); hold on
     xlabel('Time (min)');     ylabel({'\Delta\Psi (mV)'});
     set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
     box off;   hold on
end
ylim([100 225]);  yticks([100:25:225])
xlim([0 8]);  xticks([0:2:8])




