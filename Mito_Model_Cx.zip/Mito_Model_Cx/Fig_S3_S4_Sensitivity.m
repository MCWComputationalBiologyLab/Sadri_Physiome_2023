%% Evaluate the cost function in the neighborhood of the optimal parameter estimates
close all; clear all; clc
%% load parameters
run Read_Condt
addpath('.\Sensitivity_CCM')
load Model_Params_Cx; mpar=param; 
%% plot settings 
Position31=[.05,.05, 6, 12];
Position1E= [.5,.5, 18, 4];
text_size= 22;  linewidth= 3; 

%% Compute parameter sensitivity coefficients and cost function sensitivity
load dE_dp;  load dlnE_dlnp; 
set(figure(31),'Units','inches','Position',Position1E,'PaperPosition',Position1E); % figure setting 
bar(dlnE_dlnP(1,1:end),'FaceColor', [0.35 0.35 0.35],'EdgeColor','flat','LineWidth',linewidthBar)
ylabel({'Normalized','Sensitivity'}) % from the code results 
set(gca,'xtick',1:24,'xticklabel',{'PDH','CITS','IDH','AKGDH','SCAS','NDK','FH','MDH','GOT','CI','CII',...
    'CIII','CIV','CV','PYRH','GLUH','DCCS','DCCM','TCC','OME','GAE','ANT','PIC','HLeak'});  xtickangle(45) 
set(gcf,'color','w');   set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold'); box off;

%% plots
%%% param grouped into TCA, ETC, and transporters
load NormP_mat; load NormE_mat;
yvalues={'PDH','CITS','IDH','AKGDH','SCAS','NDK','FH','MDH','GOT','CI','CII',...
    'CIII','CIV','CV','PYRH','GLUH','DCCS','DCCM','TCC','OME','GAE','ANT','PIC','HLeak'};
set(figure(41),'Units','inches','Position',Position31,'PaperPosition',Position31); 
for i=1:length(mpar)
    if i>=1 && i<=9
    figure(41); subplot(3,1,1) % TCA
    plot(NormP_mat(:,i),NormE_mat(:,i),'-','linewidth',linewidth); hold on;
    ylabel('E/E_0');  xlabel('P/P_0'); title('TCA Enzymes');
    xlim([.5 1.5]);  xticks([0.5:.25:1.5]);  
    ylim([0 10]); yticks([0:2.5:10]); 
    lgd1=legend({'PDH','CITS','IDH','AKGDH','SCAS','NDK','FH','MDH','GOT'},'Location','northeast'); legend boxoff;
    lgd1.NumColumns = 2;
    set(gca,'LineWidth',linewidth,'FontSize',text_size,'FontWeight','bold'); box off

    elseif i>=10 && i<=14 || i>=22
    figure(41); subplot(3,1,2) % ETC and phosphate transporters
    plot(NormP_mat(:,i),NormE_mat(:,i),'-','linewidth',linewidth); hold on;
    ylabel('E/E_0');  xlabel('P/P_0'); title('ETC and Phosphate Transporters'); 
    xlim([.5 1.5]);  xticks([0.5:.25:1.5]);  
    ylim([0 10]); yticks([0:2.5:10]); 
    lgd2=legend({'CI','CII', 'CIII','CIV','CV','ANT','PIC','HLeak'},'Location','northeast'); legend boxoff;
    lgd2.NumColumns = 2;
    set(gca,'LineWidth',linewidth,'FontSize',text_size,'FontWeight','bold'); box off

    elseif i>=15 && i<=21 % transporters 
    figure(41); subplot(3,1,3) % TCA
    plot(NormP_mat(:,i),NormE_mat(:,i),'-','linewidth',linewidth); hold on;
     ylabel('E/E_0');  xlabel('P/P_0'); title('Metabolite Transporters'); 
    xlim([.5 1.5]);  xticks([0.5:.25:1.5]);  
    ylim([0 10]); yticks([0:2.5:10]); 
    lgd3=legend({'PYRH','GLUH','DCCS','DCCM','TCC','OME','GAE'},'Location','northeast'); legend boxoff;
    lgd3.NumColumns = 2;
    set(gca,'LineWidth',linewidth,'FontSize',text_size,'FontWeight','bold'); box off
    end
end

