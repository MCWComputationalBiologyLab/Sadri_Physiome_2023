function J_FH=FH(FUMm,MALm,pH_m,p)
% Reaction 7: Fumarate Hydratase (FH)- Enzyme 
% FUMm ⇌ MALm 	
% Reaction 8 in the supplement 

%%% Thermodynamics 
dGr0= -3.6; % kJ/mol Gibbs free energy of the reaction at pH=7 [Li etal 2011]
Keq0=exp(-dGr0/(p.R_con*p.Tem));
Keq=Keq0;

%%% Assign Km parameters
KA=1800e-6; % M Fumarate
KB=1800e-6; % M Malate 

%%% Assign conct 
A=FUMm;
B=MALm;

%%% Flux 
deno=(1+A/KA)*(1+B/KB);
J_FH =1/KA/KB*(A-B/Keq)/deno;