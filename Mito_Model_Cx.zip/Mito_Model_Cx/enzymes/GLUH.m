function T_GLUH=GLUH(GLUe,He,GLUm,Hm,p)
% Transport 2 - GLUH
% Glutamate-Hydrogen co-transporter between e and m
% e: extra mitochondria region (buffer)
% m: matrix mitochondria region 
% GLUe + He+ ⇌ GLUm + Hm+ 		

%%% Assign Km parameters (Zhang 2018)
KA=1.4e-3; % Glutamate binding constant 
KB=1e-7; % H+ binding constant 
KC=KA;  KD=KB;

%%% Assign conct
A=GLUe;
B=He;
C=GLUm;
D=Hm;

%%% Flux
deno=1+A/KA+C/KC+B/KB+D/KD+A*B/KA/KB+C*D/KC/KD;
T_GLUH=1/KB/KA*(A*B-C*D)/deno;
