function J_SCAS=SCAS(SCAm,GDPm,Pim,SUCm,GTPm,COAm,pH_m,p)
% Reaction 5: succinyl-coenzyme A synthetase (SCAS)- Enzyme 
% SCoAm + GDPm + Pim ⇌ SUCm + GTPm + CoAm + Hm+	

%%% Thermodynamics and pH 
dGr0= 1.26; % kJ/mol Gibbs free energy of the reaction at pH=7
Keq0=exp(-dGr0/(p.R_con*p.Tem));
Keq=Keq0*10^(pH_m-7); % pH correction 

%%% Assign Km parameters (Zhang 2018)
KA=1.2538e-5; % M Succinyl-coenzyme A synthase 
KB=5.6977e-6; % M GDP
KC=2.1e-3; % M Pi
KD=4.51e-4; % M Succinate 
KE=2.3143e-5; % M GTP
KF=1.7735e-5; % M coenzyme A

%%% Assign conct 
A=SCAm;
B=GDPm;
C=Pim;
D=SUCm;
E=GTPm;
F=COAm;

%%% Flux
deno=(1+A/KA+D/KD+F/KF+D*F/KD/KF)*(1+B/KB+C/KC+E/KE+B*C/KB/KC); 
J_SCAS= 1/KA/KB/KC*(A*B*C-D*E*F/Keq)/deno;
