function T_MAL_aKG=OME(aKGm,MALe,aKGe,MALm,p)
% Transport 6 - OME
% AKG-MAL Exchanger (OME)
% e: extra mitochondria region (buffer)
% m: matrix mitochondria region 
% aKGm + MALe ⇌ aKGe + MALm  Antipoter 

%%% Assign Km parameters (Zhang 2018)
KA=0.24e-3; % alpha-ketoglutrat (aKG) binding constant 
KB=1e-3; % Malate binding constant 
KC=KA;  KD=KB;

%%% Assign conct
A=aKGm;
B=MALe;
C=aKGe; 
D=MALm;

%%% Flux
deno=1+A/KA+B/KB+C/KC+D/KD+A*B/KA/KB+C*D/KA/KB;
T_MAL_aKG=1/KA/KB*(A*B-C*D)/deno;
