function J_CITS=CITS(ACOAm,OXAm,COAm,CITm,pH_m,p)
% Reaction 2: Citrate synthase (CITS)- Enzyme
% ACoAm + OXAm ⇌ CoAm + CITm +2Hm+							     

%%% Thermodynamics and pH
dGr0= -36.61; % kJ/mol Gibbs free energy of the reaction at pH=7 [Wu etal 2011] 
Keq0=exp(-dGr0/(p.R_con*p.Tem));
Keq=Keq0*10^(2*(pH_m-7)); % pH correction for 2H+

%%% Assign Km parameters (Zhang 2018)
KA=3.9e-6; % M Acetyl-coenzyme
KB=4.53e-6; % M Oxaloacetate
KC=57.9e-6; % M Coenzyme A
KD=4.3e-3; % M Citrate

%%% Assign conct 
A=ACOAm;
B=OXAm;
C=COAm;
D=CITm;

%%% flux
deno=(1+A/KA+C/KC)*(1+B/KB)*(1+D/KD);
J_CITS =1/KA/KB*(A*B-C*D/Keq)/deno;