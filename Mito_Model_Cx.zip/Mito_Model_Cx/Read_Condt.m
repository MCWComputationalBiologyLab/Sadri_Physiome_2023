%% declare variables 
% X: state variables;  T: time in min;  J: fuxes;  Pk: peak values of fluxes;  HPk: half the peak values  
% c stands for cell structure; v stand for vector 
addpath('.\enzymes')
load Model_Params
p.org=2; % organ 
p.Algt=1; % algorithm 
p.ISub=1; % initial substrate 
p.NSub=5; % number of substrates  and last substrate
p.NPar=24; % number of parameters
p.NOde=37; % number of ODEs
p.close_system=1; % 1 simulates a closed system like Oroboros, and 0 simulates an open system like PTI
p.Q10_corr=p.Q10_con.^((p.Tem-p.Tem_Stnd)/10); % Xiao p.Tem and p.Tem_Stnd are temps at which reaction rate are measured and calsulated, respectively 
p.tstep = 1/60;   % time step min
p.beta=.35;
load Exp_data_Cx;  data = data_COR;
load Model_Params_Cx;     p.pest=param; % estimated Vmax
p.Ve=.3*5e-3; % based on experimental condition buffer_Vol/mito_Vol 
p.time=2*[1, .5, .5, .5, 1, 1, 1.25, 1.75, 3,2]';

    