%% Clear worksapce
close all; 
clear all; 
clc;
warning off; 
format long; %format short e;
tic % measure elapsed time 

%% size_index for plots
text_size= 24; 
linewidth= 3; 
%%% static plots
linewidthBar= 3;
Position1E= [.5,.5, 18, 4.5];
grayColor = [.7 .7 .7];
%% read parameters
load Model_Params_Cx; % linear scale param
Params_temp=log10(param); % log scale
pcx.pest=10.^Params_temp; % linear scale
%%
CUF=1e9; % conversion unit factor to nmol/min/mg
set(figure(91),'Units','inches','Position',Position1E,'PaperPosition',Position1E); % figure setting 
bar(CUF*pcx.pest(:,1),'FaceColor', [0.35 0.35 0.35],'EdgeColor','flat','LineWidth',linewidthBar)
ylim([0 10e4]); yticks(0:2e4:10e4)
ylabel({'V_m_a_x',' (nmol/min/mg)'})
set(gca,'xtick',1:24,'xticklabel',{'PDH','CITS','IDH','AKGDH','SCAS','NDK','FH','MDH','GOT','CI','CII',...
    'CIII','CIV','CV','PYRH','GLUH','DCCS','DCCM','TCC','OME','GAE','ANT','PIC','HLeak'});  xtickangle(45) 
set(gcf,'color','w');   set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold'); box off;


