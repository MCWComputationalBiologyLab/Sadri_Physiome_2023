%% dADP sbstrate cont simulations
%% Clear worksapce
close all; clc;
clear all; 
warning off; format long; %format short e;
tic % measure elapsed time 
%% run the model
run Driver_AllFig; 
% for NADH linked substrates (PM,GM,AM) p.ISub=1; p.NSub=3; 
p.ISub=1; % initial substrate 
p.NSub=3; % number of substrates  and last substrate
% for FADH2-linked substrates p.ISub=4; p.NSub=5; 
% p.ISub=4; % initial substrate 
% p.NSub=5; % number of substrates  and last substrate

%% plots settings
text_size= .9*12; 
linewidth= 1.5; 
Position66= [.05,.05, 16.5, 13];
%% plots
p.unt=1e6;  % conversion unit for metabolites 
St=1; Ed=length(Tv)-St;
xst=0; xend=20; stepx=5; % define axis boundaries
set(figure(60),'Units','inches','Position',Position66,'PaperPosition',Position66); % figure setting
cl =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
   %% NADH-NAD
    subplot(6,6,1)
    plot(Tv(St:Ed),Xv(St:Ed,p.iNADHm,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     ylabel({'NADH (\muM)'}); % ylabel({'NADH','(\muM)'}); 
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
   % lgd1=legend({'PM','GM','AM','SUC','SUC+ROT'},'Location','northwest'); legend boxoff; lgd1.NumColumns = 1;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=3000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=3000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,2)
    plot(Tv(St:Ed),Xv(St:Ed,p.iNADm,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');   ylabel({'NAD (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=3000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=3000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
    %% UQH2-UQ
    subplot(6,6,3)
    plot(Tv(St:Ed),Xv(St:Ed,p.iUQH2m,i)*p.unt,cl(i),'linewidth',linewidth);   hold on
    xlabel('Time (min)');     ylabel({'UQH2 (\muM)'}); %ylabel({'UQH2 (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;  
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=900; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=1500; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,4)
    plot(Tv(St:Ed),Xv(St:Ed,p.iUQm,i)*p.unt,cl(i),'linewidth',linewidth);  hold on
    xlabel('Time (min)');   ylabel({'UQ (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=1500; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=1800; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
    %% Cytcred-Cytcox
    subplot(6,6,5)
    plot(Tv(St:Ed),Xv(St:Ed,p.iCytCred,i)*p.unt,cl(i),'linewidth',linewidth);   hold on
    xlabel('Time (min)');     ylabel({'Cytcred (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=510; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=1200; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,6)
    plot(Tv(St:Ed),Xv(St:Ed,p.iCytCoxi,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');   ylabel({'Cytcox (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    % ax.YLim=[0 inf];
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=3000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=3000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
    %% ATPm-ATPe
    subplot(6,6,7)
    plot(Tv(St:Ed),Xv(St:Ed,p.iATPm,i)*p.unt,cl(i),'linewidth',linewidth);  hold on
    xlabel('Time (min)');     ylabel({'ATPm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=7020; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=9000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,8)
    plot(Tv(St:Ed),Xv(St:Ed,p.iATPe,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)'); ylabel({'ATPe (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=720; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=900; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
    %% ADPm-ADPe
    subplot(6,6,9)
    plot(Tv(St:Ed),Xv(St:Ed,p.iADPm,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     ylabel({'ADPm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=12000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=12000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,10)
    plot(Tv(St:Ed),Xv(St:Ed,p.iADPe,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');   ylabel({'ADPe (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=300; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=300; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
    %% Pim-Pie
    subplot(6,6,11)
    plot(Tv(St:Ed),Xv(St:Ed,p.iPim,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     ylabel({'Pim (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=15000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=18000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,12)
    plot(Tv(St:Ed),Xv(St:Ed,p.iPie,i)*p.unt,cl(i),'linewidth',linewidth);  hold on
    xlabel('Time (min)');  ylabel({'Pie (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=6000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=6000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
    %% Pyruvate m-e
    subplot(6,6,13)
    plot(Tv(St:Ed),Xv(St:Ed,p.iPYRm,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     ylabel({'PYRm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);  box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=15000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy]) 
    elseif i==4 || i==5
    Mny=0; Mxy=150; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,14)
    plot(Tv(St:Ed),Xv(St:Ed,p.iPYRe,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');  ylabel({'PYRe (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=6000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=.09; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
%% ACOA-COA
    subplot(6,6,15)
    plot(Tv(St:Ed),Xv(St:Ed,p.iACOAm,i)*p.unt,cl(i),'linewidth',linewidth);  hold on
    xlabel('Time (min)');     ylabel({'ACOAm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=1200; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=600; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,16)
    plot(Tv(St:Ed),Xv(St:Ed,p.iCOAm,i)*p.unt,cl(i),'linewidth',linewidth); hold on 
    xlabel('Time (min)');    ylabel({'COAm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off; 
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=1200; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=1200; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
%% Citrate
    subplot(6,6,17)
    plot(Tv(St:Ed),Xv(St:Ed,p.iCITm,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     ylabel({'CITm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=2400; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=15; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,18)
    plot(Tv(St:Ed),Xv(St:Ed,p.iCITe,i)*p.unt,cl(i),'linewidth',linewidth);  hold on
    xlabel('Time (min)');     ylabel({'CITe (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=300; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=.09; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
%% aKetoglutrate
    subplot(6,6,19)
    plot(Tv(St:Ed),Xv(St:Ed,p.iaKGm,i)*p.unt,cl(i),'linewidth',linewidth); hold on 
    xlabel('Time (min)');     ylabel({'AKGm (\muM)'}); 
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=6000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=6; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,20)
    plot(Tv(St:Ed),Xv(St:Ed,p.iaKGe,i)*p.unt,cl(i),'linewidth',linewidth);  hold on
    xlabel('Time (min)');     ylabel({'AKGe (\muM)'}); 
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    ax=gca;     ax.YLim=[0 inf];
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=6000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=.03; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    %% SCA-SUC
    subplot(6,6,21)
    plot(Tv(St:Ed),Xv(St:Ed,p.iSCAm,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     ylabel({'SCoAm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=1.8; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])  
    elseif i==4 || i==5
    Mny=0; Mxy=900; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
   
    subplot(6,6,22)
    plot(Tv(St:Ed),Xv(St:Ed,p.iSUCm,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     ylabel({'SUCm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=480; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=30000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end


    subplot(6,6,23)
    plot(Tv(St:Ed),Xv(St:Ed,p.iSUCe,i)*p.unt,cl(i),'linewidth',linewidth);  hold on
    xlabel('Time (min)');     ylabel({'SUCe (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);  box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=120; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=12000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
%% GTPm-GDPm
    subplot(6,6,24)
    plot(Tv(St:Ed),Xv(St:Ed,p.iGTPm,i)*p.unt,cl(i),'linewidth',linewidth);  hold on
    xlabel('Time (min)');     ylabel({'GTPm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=630; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=900; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,25)
    plot(Tv(St:Ed),Xv(St:Ed,p.iGDPm,i)*p.unt,cl(i),'linewidth',linewidth);  hold on
    xlabel('Time (min)');     ylabel({'GDPm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);  box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=1200; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=1200; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
%% FUM-Malate
    subplot(6,6,26)
    plot(Tv(St:Ed),Xv(St:Ed,p.iFUMm,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     ylabel({'FUMm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=1800; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])  
    elseif i==4 || i==5
    Mny=0; Mxy=900; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,27)
    plot(Tv(St:Ed),Xv(St:Ed,p.iMALm,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     ylabel({'MALm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=7500; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])  
    elseif i==4 || i==5
    Mny=0; Mxy=4500; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,28)
    plot(Tv(St:Ed),Xv(St:Ed,p.iMALe,i)*p.unt,cl(i),'linewidth',linewidth);  hold on
    xlabel('Time (min)');     ylabel({'MALe (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);  box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=3000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=900; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
%% OXA
    subplot(6,6,29)
    plot(Tv(St:Ed),Xv(St:Ed,p.iOXAm,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');   ylabel({'OXA (\muM)'})
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=300; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=300; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
%% Glutamate
    subplot(6,6,30)
    plot(Tv(St:Ed),Xv(St:Ed,p.iGLUm,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     ylabel({'GLUm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=15000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=.3; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,31)
    plot(Tv(St:Ed),Xv(St:Ed,p.iGLUe,i)*p.unt,cl(i),'linewidth',linewidth);  hold on
    xlabel('Time (min)');     ylabel({'GLUe (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);  box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=6000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=.15; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
%% Aspartate
    subplot(6,6,32)
    plot(Tv(St:Ed),Xv(St:Ed,p.iASPm,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     ylabel({'ASPm (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=.6; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=.6; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

    subplot(6,6,33)
    plot(Tv(St:Ed),Xv(St:Ed,p.iASPe,i)*p.unt,cl(i),'linewidth',linewidth);  hold on
    xlabel('Time (min)');     ylabel({'ASPe (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);  box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=180; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=.09; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
%% O2
    subplot(6,6,34)
    plot(Tv(St:Ed),Xv(St:Ed,p.iO2m,i)*p.unt,cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     ylabel({'O_2 (\muM)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);  box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=0; Mxy=240; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=240; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end
%% dPsi
    subplot(6,6,35)
    plot(Tv(St:Ed),Xv(St:Ed,p.idPsi,i),cl(i),'linewidth',linewidth); hold on
    xlabel('Time (min)');     ylabel({'\Delta\Psi (mV)'});
    set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);  box off;
    xlim([xst xend]);  xticks([xst:stepx:xend]); 
    if  i==1 || i==2 ||i==3
    Mny=90; Mxy=210; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    elseif i==4 || i==5
    Mny=0; Mxy=3000; stepy=(Mxy-Mny)/3;
    ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
    end

end