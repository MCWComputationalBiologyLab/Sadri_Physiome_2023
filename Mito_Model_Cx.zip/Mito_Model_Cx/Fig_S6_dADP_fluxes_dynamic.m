%% dADP flux simulations 
%% Clear worksapce
close all; 
clear all; 
clc;
warning off; 
format long; 
tic % measure elapsed time 
%% run the model
run Driver_AllFig; 
% for NADH linked substrates (PM,GM,AM) p.ISub=1; p.NSub=3; 
p.ISub=5; % initial substrate 
p.NSub=5; % number of substrates  and last substrate
% for FADH2-linked substrates p.ISub=4; p.NSub=5; 
% p.ISub=4; % initial substrate 
% p.NSub=5; % number of substrates  and last substrate
%% plots settings
text_size= 13; 
linewidth= 1.5; 
Position66= [.05,.05, 16, 12];

%% plots
Es=3; St=10; Ed=length(Tv)-St;
for i=p.ISub:1:p.NSub
for j=1:1:p.NPar
mx(j,1)=max(Jv(st:Ed,j,i)); % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first');  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+10,j,i); % substitiute the max with the previous value
mn(j,1)=min(Jv(st:Ed,j,i)); % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mn(j,1),1,'first');  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+10,j,i); % substitiute the max with the previous value
end
mx(j,1)=max(Jv(st:Ed,j,i)); % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first');  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+5,j,i); % substitiute the max with the previous value
mx(j,1)=max(Jv(st:Ed,j,i)); % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first');  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+5,j,i); % substitiute the max with the previous value
mx(j,1)=max(Jv(st:Ed,j,i)); % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first');  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+5,j,i); % substitiute the max with the previous value
mx(j,1)=max(Jv(st:Ed,j,i)); % find the maximum 
Ix(j,1)=find(Jv(st:Ed,j,i)==mx(j,1),1,'first');  % find the correspondind index 
Jv(Ix(j,1),j,i)=Jv(Ix(j,1)+5,j,i); % substitiute the max with the previous value
end
% ax=gca;     ax.YLim=[-inf inf] 
xst=0; xend=20; stepx=5;
%% 7 dynamic flux 
%% PDH
set(figure(70),'Units','inches','Position',Position66,'PaperPosition',Position66); % figure setting
cl =['r','g','b','c','m'];
for i=p.ISub:1:p.NSub
subplot(5,5,1)
plot(Tv(St:Ed),Jv(St:Ed,p.iPDH,i),cl(i),'linewidth',linewidth); hold on
xlabel('Time (min)');     %ylabel({'J_P_D_H','(nmol/min/mg)'}); 
ylabel({'J_P_D_H'}); 
% lgd1=legend({'PM','GM','AM','SUC','SUC+ROT'},'Location','northeast'); legend boxoff; lgd1.NumColumns = 1;
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;
xlim([xst xend]);  xticks([xst:stepx:xend]); 
if i==1 || i==2 || i==3
Mny=0; Mxy=90; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=.3; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% CITS
subplot(5,5,2)
plot(Tv(St:Ed),Jv(St:Ed,p.iCITS,i),cl(i),'linewidth',linewidth); hold on
xlabel('Time (min)');     ylabel({'J_C_I_T_S'}); %ylabel({'J_C_I_T_S','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off; 
if i==1 || i==2 || i==3
Mny=0; Mxy=90; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=3; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% ICDH
subplot(5,5,3)
plot(Tv(St:Ed),Jv(St:Ed,p.iICDH,i),cl(i),'linewidth',linewidth); hold on
xlabel('Time (min)');     ylabel({'J_I_C_D_H'}); %ylabel({'J_I_C_D_H','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;  
xlim([xst xend]);  xticks([xst:stepx:xend]); 
if i==1 || i==2 || i==3
Mny=0; Mxy=3; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=6; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% AKGDH
subplot(5,5,4)
plot(Tv(St:Ed),Jv(St:Ed,p.iAKGDH,i),cl(i),'linewidth',linewidth); hold on
xlabel('Time (min)');     ylabel({'J_A_K_G_D_H'}); %ylabel({'J_A_K_G_D_H','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off;   
xlim([xst xend]);  xticks([xst:stepx:xend]); 
if i==1 || i==2 || i==3
Mny=0; Mxy=30; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=3; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% SCAS
subplot(5,5,5)
plot(Tv(St:Ed),Jv(St:Ed,p.iSCAS,i),cl(i),'linewidth',linewidth); hold on
xlabel('Time (min)');     ylabel({'J_S_C_A_S'}); %ylabel({'J_S_C_A_S','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off; 
stepx=5;    xlim([xst xend]);  xticks([xst:stepx:xend]); 
if i==1 || i==2 || i==3
Mny=0; Mxy=30; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-3; Mxy=21; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% NDK
subplot(5,5,6)
plot(Tv(St:Ed),Jv(St:Ed,p.iNDK,i),cl(i),'linewidth',linewidth); hold on
xlabel('Time (min)');     %ylabel({'J_N_D_K','(nmol/min/mg)'});  
ylabel({'J_N_D_K'}); 
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off; 
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   
if i==1 || i==2 || i==3
Mny=0; Mxy=30; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-5; Mxy=40; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% SDH
subplot(5,5,7)
plot(Tv(St:Ed),Jv(St:Ed,p.iCII,i),cl(i),'linewidth',linewidth); hold on
xlabel('Time (min)');     ylabel({'J_S_D_H'}); %ylabel({'J_S_D_H','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth); box off; 
xlim([xst xend]);  xticks([xst:stepx:xend]); 
if i==1 || i==2 || i==3
Mny=-40; Mxy=20; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=150; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% FH
subplot(5,5,8)
plot(Tv(St:Ed),Jv(St:Ed,p.iFH,i),cl(i),'linewidth',linewidth);  hold on
xlabel('Time (min)');     ylabel({'J_F_H'}); %ylabel({'J_F_H','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;  
if i==1 || i==2 || i==3
Mny=-40; Mxy=20; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=150; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% MDH
subplot(5,5,9)
plot(Tv(St:Ed),Jv(St:Ed,p.iMDH,i),cl(i),'linewidth',linewidth);  hold on
xlabel('Time (min)');     ylabel({'J_M_D_H'}); %ylabel({'J_M_D_H','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;  
if i==1 || i==2 || i==3
Mny=0; Mxy=60; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-1; Mxy=11; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% GOT
subplot(5,5,10)
plot(Tv(St:Ed),Jv(St:Ed,p.iGOT,i),cl(i),'linewidth',linewidth); hold on
xlabel('Time (min)');     ylabel({'J_G_O_T'}); %ylabel({'J_G_O_T','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;  
if i==1 || i==2 || i==3
Mny=-30; Mxy=0; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-.03e-5; Mxy=.09e-5; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% CI
subplot(5,5,11)
plot(Tv(St:Ed),Jv(St:Ed,p.iCI,i),cl(i),'linewidth',linewidth);  hold on
xlabel('Time (min)');     %ylabel({'J_C_I','(nmol/min/mg)'}); 
ylabel({'J_C_I'}); 
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   
if i==1 || i==2 || i==3
Mny=-30; Mxy=180; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-150; Mxy=300; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% CII
subplot(5,5,12)
plot(Tv(St:Ed),Jv(St:Ed,p.iCII,i),cl(i),'linewidth',linewidth);   hold on
xlabel('Time (min)');    ylabel({'J_C_I_I'}); % ylabel({'J_C_I_I','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   
if i==1 || i==2 || i==3
Mny=-50; Mxy=25; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=150; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% CIII
subplot(5,5,13)
plot(Tv(St:Ed),Jv(St:Ed,p.iCIII,i),cl(i),'linewidth',linewidth);  hold on
xlabel('Time (min)');     ylabel({'J_C_I_I_I'}); %ylabel({'J_C_I_I_I','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   
if i==1 || i==2 || i==3
Mny=0; Mxy=120; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=150; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% CIV
subplot(5,5,14)
plot(Tv(St:Ed),Jv(St:Ed,p.iCIV,i),cl(i),'linewidth',linewidth);  hold on
xlabel('Time (min)');     ylabel({'J_C_I_V'}); %ylabel({'J_C_I_V','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;  
if i==1 || i==2 || i==3
Mny=0; Mxy=120; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=150; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% CV
subplot(5,5,15)
plot(Tv(St:Ed),Jv(St:Ed,p.iCV,i),cl(i),'linewidth',linewidth); hold on
xlabel('Time (min)');     ylabel({'J_C_V'}); %ylabel({'J_C_V','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   
if i==1 || i==2 || i==3
Mny=0; Mxy=300; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=300; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% TRANSPORTERS 
%% PYRH
subplot(5,5,16)
cl =['r','g','b','c','m'];
mx=max(Jv(st:Ed,p.iPYRH,1)); % find the maximum of PYRH flux
Ix=find(Jv(st:Ed,p.iPYRH,1)==mx,1,'first');  % find the correspondind index 
Jv(Ix,p.iPYRH,1)=Jv(Ix-1,p.iPYRH,1); % subsstitiute the max with the previous value
plot(Tv(St:Ed),Jv(St:Ed,p.iPYRH,i),cl(i),'linewidth',linewidth); hold on
xlabel('Time (min)');    % ylabel({'J_P_Y_R_H','(nmol/min/mg)'}); 
ylabel({'J_P_Y_R_H'}); 
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;  
if i==1 || i==2 || i==3
Mny=0; Mxy=60; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-.01e-5; Mxy=.02e-5; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% GLUH
subplot(5,5,17)
mx=max(Jv(st:Ed,p.iGLUH,2)); % find the maximum of GLUH flux
Ix=find(Jv(st:Ed,p.iGLUH,2)==mx,1,'first');  % find the correspondind index 
Jv(Ix,p.iGLUH,2)=Jv(Ix-1,p.iGLUH,2); % subsstitiute the max with the previous value
plot(Tv(St:Ed),Jv(St:Ed,p.iGLUH,i),cl(i),'linewidth',linewidth); hold on
xlabel('Time (min)');     ylabel({'J_G_L_U_H'}); %ylabel({'J_G_L_U_H','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   
if i==1 || i==2 || i==3
Mny=-.06; Mxy=.0; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-.03e-5; Mxy=.06e-5; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% DCC1;    SUC-Pi
subplot(5,5,18)
plot(Tv(St:Ed),Jv(St:Ed,p.iDCC1,i),cl(i),'linewidth',linewidth);  hold on
xlabel('Time (min)');     ylabel({'J_D_C_C_S'}); %ylabel({'J_S_U_C_P_i','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;  
if i==1 || i==2 || i==3
Mny=-50; Mxy=10; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=150; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% DCC2:     MAL-Pi
subplot(5,5,19)
plot(Tv(St:Ed),Jv(St:Ed,p.iDCC2,i),cl(i),'linewidth',linewidth);  hold on
xlabel('Time (min)');     ylabel({'J_D_C_C_M'}); %ylabel({'J_M_A_L_P_i','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   
if i==1 || i==2 || i==3
Mny=-30; Mxy=60; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-150; Mxy=0; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% TCC:  MAL-CIT  
subplot(5,5,20)
plot(Tv(St:Ed),Jv(St:Ed,p.iTCC,i),cl(i),'linewidth',linewidth);  hold on
xlabel('Time (min)');     ylabel({'J_T_C_C'}); %ylabel({'J_T_C_C','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;  
if i==1 || i==2 || i==3
Mny=0; Mxy=90; stepy=Mxy/3;
ylim([Mny Mxy]);   yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=.15; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% OME: Aspartate-Malate
subplot(5,5,21)
plot(Tv(St:Ed),Jv(St:Ed,p.iOME,i),cl(i),'linewidth',linewidth);  hold on
xlabel('Time (min)');     %ylabel({'J_O_M_E','(nmol/min/mg)'}); 
ylabel({'J_O_M_E'}); 
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   %hold off   
if i==1 || i==2 || i==3
Mny=-25; Mxy=5; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=.012; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% AGE: HGLU-ASP
subplot(5,5,22)
plot(Tv(St:Ed),Jv(St:Ed,p.iGAE,i),cl(i),'linewidth',linewidth);  hold on
xlabel('Time (min)');     ylabel({'J_G_A_E'}); %ylabel({'J_G_A_E','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   
if i==1 || i==2 || i==3
Mny=0; Mxy=24; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=-.06e-5; Mxy=.06e-5; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% ANT
subplot(5,5,23)
plot(Tv(St:Ed),Jv(St:Ed,p.iANT,i),cl(i),'linewidth',linewidth);  hold on
xlabel('Time (min)');    ylabel({'J_A_N_T'}); % ylabel({'J_A_N_T','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;   
if i==1 || i==2 || i==3
Mny=0; Mxy=420; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=450; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% PIC
subplot(5,5,24)
plot(Tv(St:Ed),Jv(St:Ed,p.iPIC,i),cl(i),'linewidth',linewidth);   hold on
xlabel('Time (min)');     ylabel({'J_P_I_C'}); %ylabel({'J_P_I_C','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;  
if i==1 || i==2 || i==3
Mny=0; Mxy=300; stepy=Mxy/3;
ylim([Mny Mxy]); yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=210; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
%% HLEAK
subplot(5,5,25)
plot(Tv(St:Ed),Jv(St:Ed,p.iHLEAK,i),cl(i),'linewidth',linewidth); hold on
xlabel('Time (min)');     ylabel({'J_H_L_E_A_K'}); %ylabel({'J_H_L_E_A_K','(nmol/min/mg)'});
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlim([xst xend]);  xticks([xst:stepx:xend]); 
box off;    
if i==1 || i==2 || i==3
Mny=0; Mxy=240; stepy=Mxy/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
elseif i==4 || i==5
Mny=0; Mxy=450; stepy=(Mxy-Mny)/3;
ylim([Mny Mxy]);  yticks([Mny:stepy:Mxy])
end
end
