%% proton leak ADP 200uM
%% clear workspace 
clear all
close all
clc
warning off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% declare variables 
run Read_Condt
%% plots settings 
text_size= 65; 
linewidth= 10; 
Position1= [.05,.05, 14, 12];
%% load parameters
load Model_Params_Cx;     p.pest=param; % estimated Vmax
p.pest(1:p.NPar)=param; p.pest; % estimated Vmax
%% experimental condition
p.Ve=.3*5e-3; % buffer_Vol/mito_Vol % .2mg/mL
p.time=[2, 1, 1, 5,1]';% ADPe is obtained at 4th duration 2
%% load data
% data coloumns indicate: [PM GM AM Suc SucRot]
JO2_Pkd=[data.JO2_Pk(:,1) data.JO2_Pk(:,2) data.JO2_Pk(:,3) data.JO2_Pk(:,4) data.JO2_Pk(:,5)]; % nM
JO2_Pk_Err=[data.JO2_Pk_Err(:,1) data.JO2_Pk_Err(:,2) data.JO2_Pk_Err(:,3) data.JO2_Pk_Err(:,4) data.JO2_Pk_Err(:,5)]; % nM

%% substrates and ADP additions 
PYR_index=[1 0 0 0 0];
GLU_index=[0 1 0 0 0];
aKG_index=[0 0 1 0 0];
MAL_index=[1 1 1 0 0];
SUC_index=[0 0 0 1 1];
ADP_add=[0 100]*1e-6; p.ADPL=length(ADP_add); % uM
options = odeset('NonNegative',[1:p.NOde]); % concentrations of the state variables should be positive
HLF =[1:1:10]; % HLeak factor
counter1=0; p.Es=3; counter4=20;
counter5=1; % to store T, X and J with different lengths
T0ii=zeros(p.ADPL+p.Es,5);       X0ii=zeros(p.ADPL+p.Es,5);
for j=1:length(HLF)
    HLF(j);
for i=p.ISub:1:p.NSub 
X0=ICs(p); p_tem=p; 
p_tem.pest(p.iHLEAK)=HLF(j)*p.pest(p.iHLEAK); % Proton Leak
%%% solving ODEs and calculating state variables 
T0=0; jj=1; p.Es=3; % extra states 
cc=1;
for ii=1:1:p.ADPL+p.Es % ii=1: add mito, ii=2: add substrate, ii=3: add Rot i=5, ii=4-9 add 6 doses of ADP
    %%% Substrate addition 
    if ii==p.Es-1
        X0(p_tem.iMALe)=cc*MAL_index(i)*2.5e-3; % mM
        X0(p_tem.iPYRe)=cc*PYR_index(i)*5e-3; % mM
        X0(p_tem.iGLUe)=cc*GLU_index(i)*5e-3; % mM
        X0(p_tem.iaKGe)=cc*aKG_index(i)*5e-3; % mM
        X0(p_tem.iSUCe)=cc*SUC_index(i)*10e-3; % mM
    end
    if i==5 && ii==p.Es % Rot addition
        p_tem.ini_VTmax(p.iCI)=0*p_tem.ini_VTmax(p.iCI); % inhibit CI
    end 
    %%% ADP addition
    if ii>=p.Es && ii~=p.ADPL+p.Es   
        X0(p_tem.iADPe)=X0(p.iADPe)+ADP_add(jj);
        jj=jj+1;
    end
    %%% Solving ODEs
    tspan=[T0:p.tstep:(T0+p.time(ii,1))];
    [T,X] = ode15s(@ODEs, tspan, X0, options, p_tem);  
    T0=T(end,:);       X0=X(end,:);  % redefining initial values for the next time periode 
    TL(ii,i,j)=length(T);
    Tc(ii,i,j)={T};      Xc(ii,i,j)={X};  

    %%% Find where O2 becomes 0
    Xcp=Xc{ii,i}; L=length(X(:,p.iO2m));
    Xcp(5:end,p.iO2m);
    if isempty(find(Xcp(5:end,p.iO2m)==0,1,'first')); IxO2(ii,i,j)=0; ADPe_O20(ii,i,j)=0;
       wp=sprintf('cannot find IxO2 for org=%d ii=%d flx=%d',i,ii,p.iO2m); disp(wp);     
    else IxO2(ii,i,j)=find(Xcp(5:end,p.iO2m)==0,1,'first');
        counter1=0;
        ADPe_O20(ii,i,j)=1e3*Xcp(IxO2(ii,i,j),p.iADPe);
        counter1=1;
    end
    Xcp=[];

    %%% Calculating fluxes
    for zz=1:1:length(T) %length(tspan) %length(T)
        J(zz,:,i)=Fluxes(X(zz,:),p_tem);        
    end
    Jc(ii,i,j)={J(1:zz,:,i)};

    %%% finding peaks of state 3 for ODEs
   st0=5; st=st0;
   if ii<p.Es || ii==p.ADPL+p.Es
        Xmax(ii,:,i)=mean(Xc{ii,i}); 
   elseif ii>=p.Es || ii~=p.ADPL+p.Es
       if  i==4; st=2; else; st=1; end % for state 2 and Suc start from higher values    
        Xmax(ii,:,i)=max(Xc{ii,i});
        Xmin(ii,:,i)=min(Xc{ii,i});
   end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Find peaks of state 3 for fluxes
    s=13;  % CIV flux- OCR
   if ii<p.Es || ii==p.ADPL+p.Es
        JPk(ii,i)=mean(J(st:end,s,i));  % returns mean of each column   
        HPk(ii,i)=mean(J(st:end,s,i));
   elseif ii>=p.Es || ii~=p.ADPL+p.Es 
        JPk(ii,i)=max(J(st:end,s,i)); % returns max of each column 
        HPk(ii,i)=.5*max(J(st:end,s,i)); 
        RCI(ii,i,j)=JPk(ii,i)/JPk(p.Es,i);
        St2_OCR(i,j)=JPk(p.Es,i);
        dPsi_min(ii,i,j)=Xmin(ii,p.idPsi,i);
        dPsi_max(ii,i,j)=Xmax(ii,p.idPsi,i);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Find POR
    iADPe_min(ii,i,j)=min(X(:,p.iADPe));
    iADPe_max(ii,i,j)=max(X(:,p.iADPe));

    c1=8.7e-7;
    if isempty(find(X(10:end,p.iADPe)<c1,1,'first')); iADPe_Inx1(ii,i,j)=1; 
    wp=sprintf('cannot find Index ADPe 1 for org=%d ii=%d flx=%d',i,ii,s); disp(wp);
    else iADPe_Inx1(ii,i,j)=find(X(10:end,p.iADPe)<c1,1,'first');
    end

    c2=2.5e-7;
    if isempty(find(X(10:end,p.iADPe)>c2,1,'last')); iADPe_Inx2(ii,i,j)=1; 
    wp=sprintf('cannot find Index ADPe 2 for org=%d ii=%d flx=%d',i,ii,s); disp(wp);
    else iADPe_Inx2(ii,i,j)=find(X(10:end,p.iADPe)>c2,1,'last'); 
     ADP_add(jj-1); ii_keep=ii;
    counter1=iADPe_Inx2(ii,i,j); % for C_O2
    counter3_PO(ii,i,j)= iADPe_Inx2(ii,i,j); % for dC_O2
    C_O2_1(ii,i,j)=X(1,p.iO2m);
    C_O2_2(ii,i,j)=X(counter1,p.iO2m);
    dO2(ii,i,j)=abs(C_O2_2(ii,i,j)-C_O2_1(ii,i,j));
    POR(ii,i,j)=ADP_add(jj-1)/(2*dO2(ii,i,j));
    ADP_add(jj-1);
    ADPe_O20(ii,i,j);

    Xmax_NADH(ii,i,j)=Xmax(ii,p.iNADHm,i);
    Xmin_NADH(ii,i,j)=Xmin(ii,p.iNADHm,i);
    Xmax_NAD(ii,i,j)=Xmax(ii,p.iNADm,i);
    Xmin_NAD(ii,i,j)=Xmin(ii,p.iNADm,i);

    Xmax_QH2(ii,i,j)=Xmax(ii,p.iUQH2m,i);
    Xmin_QH2(ii,i,j)=Xmin(ii,p.iUQH2m,i);
    Xmax_Q(ii,i,j)=Xmax(ii,p.iUQm,i);
    Xmin_Q(ii,i,j)=Xmin(ii,p.iUQm,i);

    Xmax_Cytcred(ii,i,j)=Xmax(ii,p.iCytCred,i);
    Xmin_Cytcred(ii,i,j)=Xmin(ii,p.iCytCred,i);
    Xmax_Cytcoxi(ii,i,j)=Xmax(ii,p.iCytCoxi,i);
    Xmin_Cytcoxi(ii,i,j)=Xmin(ii,p.iCytCoxi,i);

    ADPe_start(ii,i,j)=X(1,p.iADPe);
    ADPe_finish(ii,i,j)=X(counter1,p.iADPe);
    end

    end % if ii

    Pkc(ii,i)={JPk(ii,i)};
    HPkc(ii,i)={HPk(ii,i)};

end % for ii
Tv(:,i,j)=      [Tc{2,i,j};    Tc{3,i,j};    Tc{4,i,j};    Tc{5,i,j};];
Xv(:,:,i)=1e0*  [Xc{2,i,j};    Xc{3,i,j};    Xc{4,i,j};    Xc{5,i,j};]; % M
Jv(:,:,i)=1e9*  [Jc{2,i,j};    Jc{3,i,j};    Jc{4,i,j};    Jc{5,i,j};]; % nmol/min/mg mito

St2_OCR(i,j)=mean(Jv(124:244,p.iCIV,i));
St2_dPsi(i,j)=mean(Xv(124:244,p.idPsi,i));
St2_NADH(i,j)=mean(Xv(124:244,p.iNADHm,i));
St2_NAD(i,j)=mean(Xv(124:244,p.iNADm,i));
St2_CytCred(i,j)=mean(Xv(124:244,p.iCytCred,i));
St2_CytCoxi(i,j)=mean(Xv(124:244,p.iCytCoxi,i));
St2_UQH2(i,j)=mean(Xv(124:244,p.iUQH2m,i));
St2_UQ(i,j)=mean(Xv(124:244,p.iUQm,i));

%% Plot
% %%% oCR fluxes
% figure(1); subplot(3,2,i); % OCR dynamic
% p.sp=10; % start of plot 
% OCR(:,i)=movmean(Jv(p.sp:end,p.iCIV,i),5); 
% % plot(Tv(p.sp:end,i),Jv(p.sp:end,p.iCIV,i)); hold on
% plot(Tv(p.sp:end,i,j),OCR(:,i)); hold on 
% if i==1; title('PM JO2'); elseif i==2; title('GM JO2');
% elseif i==3; title('AM JO2'); elseif i==4; title('Suc JO2');
% elseif i==5; title('Suc+Rot JO2'); end
% 
% figure(2); subplot(3,2,i) % dPsi dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.idPsi,i)); hold on
% if i==1; title('PM \Delta\Psi'); elseif i==2; title('GM \Delta\Psi');
% elseif i==3; title('AM \Delta\Psi'); elseif i==4; title('Suc \Delta\Psi');
% elseif i==5; title('Suc+Rot \Delta\Psi'); end
% 
% figure(4); subplot(3,2,i) % O2 dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iO2m,i)); hold on 
% if i==1; title('PM O2m'); elseif i==2; title('GM O2m');
% elseif i==3; title('AM O2m'); elseif i==4; title('Suc O2m');
% elseif i==5; title('Suc+Rot O2m'); end
% 
% figure(5); subplot(3,2,i) % ADPm dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iADPm,i)); hold on  
% if i==1; title('PM ADPm'); elseif i==2; title('GM ADPm');
% elseif i==3; title('AM ADPm'); elseif i==4; title('Suc ADPm');
% elseif i==5; title('Suc+Rot ADPm'); end
% 
% figure(6); subplot(3,2,i) % ATPm dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iATPm,i)); hold on
% if i==1; title('PM ATPm'); elseif i==2; title('GM ATPm');
% elseif i==3; title('AM ATPm'); elseif i==4; title('Suc ATPm');
% elseif i==5; title('Suc+Rot ATPm'); end
% 
% figure(7); subplot(3,2,i) % ATPe dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iATPe,i)); hold on  
% if i==1; title('PM ATPe'); elseif i==2; title('GM ATPe');
% elseif i==3; title('AM ATPe'); elseif i==4; title('Suc ATPe');
% elseif i==5; title('Suc+Rot ATPe'); end
% 
% figure(8); subplot(3,2,i) % ANT dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iANT,i)); hold on
% if i==1; title('PM ANT'); elseif i==2; title('GM ANT');
% elseif i==3; title('AM ANT'); elseif i==4; title('Suc ANT');
% elseif i==5; title('Suc+Rot ANT'); end
% 
% figure(9); subplot(3,2,i) % NADH dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iNADHm,i),'.-'); hold on
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iNADHm,i)/3e-3,'.-'); hold on
% if i==1; title('PM NADH'); elseif i==2; title('GM NADH');
% elseif i==3; title('AM NADH'); elseif i==4; title('Suc NADH');
% elseif i==5; title('Suc+Rot NADH'); end
% 
% figure(10); subplot(3,2,i) % NAD dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iNADm,i)/3e-3,'.-'); hold on 
% if i==1; title('PM NAD'); elseif i==2; title('GM NAD');
% elseif i==3; title('AM NAD'); elseif i==4; title('Suc NAD');
% elseif i==5; title('Suc+Rot NAD'); end
% 
% figure(11); subplot(3,2,i) % UQH2 dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iUQH2m,i),'.-'); hold on  
% if i==1; title('PM UQH2'); elseif i==2; title('GM UQH2');
% elseif i==3; title('AM UQH2'); elseif i==4; title('Suc UQH2');
% elseif i==5; title('Suc+Rot UQH2'); end
% 
% figure(12); subplot(3,2,i) % UQ dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iUQm,i)); hold on
% if i==1; title('PM -UQ'); elseif i==2; title('GM -UQ');
% elseif i==3; title('AM -UQ'); elseif i==4; title('Suc -UQ');
% elseif i==5; title('Suc+Rot -UQ'); end
% 
% figure(13); subplot(3,2,i) % CytCred dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iCytCred,i),'.-'); hold on
% if i==1; title('PM CytC-red'); elseif i==2; title('GM CytC-red');
% elseif i==3; title('AM CytC-red'); elseif i==4; title('Suc CytC-red');
% elseif i==5; title('Suc+Rot CytC-red'); end
% 
% figure(14); subplot(3,2,i) % CytCoxi dynamic
% plot(Tv(p.sp:end,i,j),Xv(p.sp:end,p.iCytCoxi,i)); hold on 
% if i==1; title('PM CytC-Oxi'); elseif i==2; title('GM CytC-Oxi');
% elseif i==3; title('AM CytC-Oxi'); elseif i==4; title('Suc CytC-Oxi');
% elseif i==5; title('Suc+Rot CytC-Oxi'); end

end % i substrate for-loop
end % j for leak factor

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plot 1 ADP redox ratios vs HLeak
cl =['r','g','b','c','m'];
%%% NADH Ratio
set(figure(51),'Units','inches','Position',Position1,'PaperPosition',Position1);
xleak =100*HLF;
Pkvx=[ADP_add]*1e6; 
for i=p.ISub:1:p.NSub
if i==1 || i==2 || i==3
St2_NADHRp(i,:)=(St2_NADH(i,1:length(HLF))./(St2_NADH(i,1:length(HLF))+St2_NAD(i,1:length(HLF)))); 
plot(xleak(:),St2_NADHRp(i,:),cl(i),'linewidth',linewidth); hold on;
elseif i==4 || i==5 
St2_NADHRp(i,:)=(St2_NADH(i,1:length(HLF))./(St2_NADH(i,1:length(HLF))+St2_NAD(i,1:length(HLF)))); 
plot(xleak(:),St2_NADHRp(i,:),cl(i),'linewidth',linewidth); hold on;
end
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlabel('Relative proton leak');   ylabel('NADH Ratio');
xtickformat('percentage');  
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
hold on
end
% lgd1=legend({'PM','GM','AM','SUC','SUC+ROT'},'Location','southeast'); legend boxoff;
% lgd1.NumColumns = 1;
box off;   hold off
set(gcf,'color','w');   set(gca,'Fontsize',text_size)
xlim([100 900]); xticks([100:200:900])
ylim([0 1]); yticks([0:.2:1])

%%% QH2 Ratio
set(figure(52),'Units','inches','Position',Position1,'PaperPosition',Position1);
xleak =100*HLF;
Pkvx=[ADP_add]*1e6; 
for i=p.ISub:1:p.NSub
if i==1 || i==2 || i==3
St2_UQH2p(i,:)=(St2_UQH2(i,1:length(HLF))./(St2_UQH2(i,1:length(HLF))+St2_UQ(i,1:length(HLF)))); 
plot(xleak(:),St2_UQH2p(i,:),cl(i),'linewidth',linewidth)
elseif i==4 || i==5 
St2_UQH2p(i,:)=(St2_UQH2(i,1:length(HLF))./(St2_UQH2(i,1:length(HLF))+St2_UQ(i,1:length(HLF)))); 
plot(xleak(:),St2_UQH2p(i,:),cl(i),'linewidth',linewidth)
end
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlabel('Relative proton leak');   ylabel('UQH2 Ratio');
xtickformat('percentage');   
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
hold on
end
box off;   hold off
set(gcf,'color','w');   set(gca,'Fontsize',text_size)
xlim([100 900]); xticks([100:200:900])

%%% Cytcred Ratio
set(figure(53),'Units','inches','Position',Position1,'PaperPosition',Position1);
xleak =100*HLF;
Pkvx=[ADP_add]*1e6; 
for i=p.ISub:1:p.NSub
if i==1 || i==2 || i==3
St2_CytCp(i,:)=(St2_CytCred(i,1:length(HLF))./(St2_CytCred(i,1:length(HLF))+St2_CytCoxi(i,1:length(HLF)))); 
plot(xleak(:),St2_CytCp(i,:),cl(i),'linewidth',linewidth)
elseif i==4 || i==5 
St2_CytCp(i,:)=(St2_CytCred(i,1:length(HLF))./(St2_CytCred(i,1:length(HLF))+St2_CytCoxi(i,1:length(HLF)))); 
plot(xleak(:),St2_CytCp(i,:),cl(i),'linewidth',linewidth)
end
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlabel('Relative proton leak');   ylabel('Cytc Ratio');
xtickformat('percentage');  
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
hold on
end
box off;   hold off
set(gcf,'color','w');   set(gca,'Fontsize',text_size)
xlim([100 900]); xticks([100:200:900])

%%% dPsi
set(figure(54),'Units','inches','Position',Position1,'PaperPosition',Position1);
xleak =100*HLF(1:1:length(HLF));
Pkvx=[ADP_add]*1e6; 
for i=p.ISub:1:p.NSub
dPsip(i,:)=dPsi_min(4,i,1:length(HLF)); hold on
plot(xleak(:),St2_dPsi(i,1:length(HLF)),cl(i),'linewidth',linewidth); hold on
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlabel('Relative proton leak');   ylabel('\Delta\Psi (mV)')
xtickformat('percentage');   
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
hold on
end
box off;   hold off
xlim([100 900]); xticks([100:200:900])
set(gcf,'color','w');   set(gca,'Fontsize',text_size)

%%% RCI
set(figure(55),'Units','inches','Position',Position1,'PaperPosition',Position1);
xleak =100*HLF(1:1:length(HLF));
Pkvx=[ADP_add]*1e6; 
for i=p.ISub:1:p.NSub
RCIp(i,:)=RCI(4,i,1:length(HLF));
plot(xleak(:),RCIp(i,:),cl(i),'linewidth',linewidth)
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth);
xlabel('Relative proton leak');   
xtickformat('percentage');   
ylabel('RCI')
set(gcf,'color','w'); set(gca,'Fontsize',text_size,'linewidth',linewidth,'FontWeight','bold');
hold on
end
box off;   hold off
set(gcf,'color','w');   set(gca,'Fontsize',text_size)
xlim([100 900]); xticks([100:200:900])






